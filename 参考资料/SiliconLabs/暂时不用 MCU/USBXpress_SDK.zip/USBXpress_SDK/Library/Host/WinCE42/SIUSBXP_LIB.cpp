// SIUSBXP_LIB.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "SIUSBXP_LIB.h"
#include "SiDirect.h"
#include "winioctl.h"
#include "ioctls.h"

// Private functions
static SI_STATUS SI_InterfaceEnable(HANDLE cyHandle);
static SI_STATUS SI_InterfaceDisable(HANDLE cyHandle);
static SI_STATUS SendSetup	(	HANDLE	cyHandle,
								LPVOID	lpSetupBuffer,
								DWORD	dwBytesToSend,
								LPDWORD	lpdwBytesSent);
static SI_STATUS GetSetup	(	HANDLE	cyHandle,
								LPVOID	lpSetupBuffer,
								DWORD	dwBytesToSend,
								LPDWORD	lpdwBytesSent);
static BOOL ValidParam(LPDWORD lpdwPointer);
static BOOL ValidParam(LPWORD lpwPointer);
static BOOL ValidParam(LPBYTE lpbPointer);
static BOOL ValidParam(LPVOID lpVoidPointer);
static BOOL ValidParam(LPVOID lpVoidPointer, LPDWORD lpdwPointer);
static BOOL ValidParam(LPDWORD lpdwPointer1, LPDWORD lpdwPointer2);
static BOOL ValidParam(HANDLE* lpHandle);
static DWORD LookupBaudRateAlias(LPWORD lpwBaudDivisor);

static SI_STATUS SI_GetBaudDivisor(HANDLE cyHandle, LPWORD lpwBaudDivisor);

// FlowControl State structure
typedef	struct SiFlowControlState
{
	// Flow Control line States

	// Flow Control input states which can be
	// Status Input == 0x00
	// Handshake line == 0x01
	BYTE	bCTS_State;
	BYTE	bDSR_State;
	BYTE	bDCD_State;

	// Flow Control output states which can be
	// held inactive == 0x00
	// held active == 0x01
	// controlled by port firmware ==0x02
	BYTE	bRTS_State;
	BYTE	bDTR_State;

	// others not used by the interface currently
	// just set them to the defaults and leave them there
	// flow replace bits
	BYTE	bSERIAL_AUTO_TRANSMIT;
	BYTE	bSERIAL_AUTO_RECEIVE;
	BYTE	bSERIAL_ERROR_CHAR;
	BYTE	bSERIAL_NULL_STRIPPING;
	BYTE	bSERIAL_BREAK_CHAR;
	BYTE	bSERIAL_XOFF_CONTINUE;

	BOOL	FlowXonXoff;

} SiFlowControlStruct;


// DLL globals
typedef struct SiGlobalStruct
{
	DWORD	dwWriteTimeout;
	DWORD	dwReadTimeout;
	SiFlowControlStruct SI_FlowStruct;
} SiGlobalStruct;


// Global containing the TLS index
static DWORD gdwTlsIndex;


// File local function that returns the pointer to the global
// data for this thread.
static SiGlobalStruct* ThreadGlobalData()
{
	SiGlobalStruct* lpGlobals; 
 
	// Retrieve a data pointer for the current thread.
 
	lpGlobals = (SiGlobalStruct*) TlsGetValue(gdwTlsIndex); 
 
	// If NULL, allocate memory for this thread.
 
	if (lpGlobals == NULL) 
	{ 
		lpGlobals = (SiGlobalStruct*) LocalAlloc(LPTR, sizeof(SiGlobalStruct));

		if (lpGlobals != NULL) 
		{
			// Initialize the values
			lpGlobals->dwWriteTimeout	= 0;
			lpGlobals->dwReadTimeout	= 0;

			lpGlobals->SI_FlowStruct.bCTS_State = SI_HELD_INACTIVE;
			lpGlobals->SI_FlowStruct.bDSR_State = SI_HELD_INACTIVE;
			lpGlobals->SI_FlowStruct.bDCD_State = SI_HELD_INACTIVE;
			lpGlobals->SI_FlowStruct.bRTS_State = SI_HELD_INACTIVE;
			lpGlobals->SI_FlowStruct.bDTR_State = SI_HELD_INACTIVE;
			lpGlobals->SI_FlowStruct.bSERIAL_AUTO_TRANSMIT = 0;
			lpGlobals->SI_FlowStruct.bSERIAL_AUTO_RECEIVE = 0;
			lpGlobals->SI_FlowStruct.bSERIAL_ERROR_CHAR = 0;
			lpGlobals->SI_FlowStruct.bSERIAL_NULL_STRIPPING = 0;
			lpGlobals->SI_FlowStruct.bSERIAL_BREAK_CHAR = 0;
			lpGlobals->SI_FlowStruct.bSERIAL_XOFF_CONTINUE = 0;
			lpGlobals->SI_FlowStruct.FlowXonXoff = FALSE;

			TlsSetValue(gdwTlsIndex, (LPVOID)lpGlobals);
		}
	}

	return lpGlobals;
}

/*BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}


// This is an example of an exported variable
SIUSBXP_LIB_API int nSIUSBXP_LIB=0;

// This is an example of an exported function.
SIUSBXP_LIB_API int fnSIUSBXP_LIB(void)
{
	return 42;
}

// This is the constructor of a class that has been exported.
// see SIUSBXP_LIB.h for the class definition
CSIUSBXP_LIB::CSIUSBXP_LIB()
{ 
	return; 
}*/

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	SiGlobalStruct* lpGlobals;

    switch (ul_reason_for_call)
	{
		// The DLL is loading due to process 
		// initialization or a call to LoadLibrary. 
		case DLL_PROCESS_ATTACH:
			{
				// Allocate TLS index
				if ((gdwTlsIndex = TlsAlloc()) == 0xFFFFFFFF)
					return FALSE;
			}

			// No break: Initialize the index for first thread.
 
		// The attached process creates a new thread.
		case DLL_THREAD_ATTACH:
			{
				// Initialize the TLS index for this thread.
				lpGlobals = (SiGlobalStruct*) LocalAlloc(LPTR, sizeof(SiGlobalStruct));

				if (lpGlobals != NULL)
				{
					// Initialize the values
					lpGlobals->dwWriteTimeout	= 0;
					lpGlobals->dwReadTimeout	= 0;

					// by default on startup everything is low
					// customer can change this by using the set flow command
					lpGlobals->SI_FlowStruct.bCTS_State = SI_HELD_INACTIVE;
					lpGlobals->SI_FlowStruct.bDSR_State = SI_HELD_INACTIVE;
					lpGlobals->SI_FlowStruct.bDCD_State = SI_HELD_INACTIVE;
					lpGlobals->SI_FlowStruct.bRTS_State = SI_HELD_INACTIVE;
					lpGlobals->SI_FlowStruct.bDTR_State = SI_HELD_INACTIVE;
					lpGlobals->SI_FlowStruct.bSERIAL_AUTO_TRANSMIT = 0;
					lpGlobals->SI_FlowStruct.bSERIAL_AUTO_RECEIVE = 0;
					lpGlobals->SI_FlowStruct.bSERIAL_ERROR_CHAR = 0;
					lpGlobals->SI_FlowStruct.bSERIAL_NULL_STRIPPING = 0;
					lpGlobals->SI_FlowStruct.bSERIAL_BREAK_CHAR = 0;
					lpGlobals->SI_FlowStruct.bSERIAL_XOFF_CONTINUE = 0;
					lpGlobals->SI_FlowStruct.FlowXonXoff = FALSE;

					TlsSetValue(gdwTlsIndex, (LPVOID)lpGlobals);
				}
			}
			break;

		// The thread of the attached process terminates.
		case DLL_THREAD_DETACH:
			{
				// Release the allocated memory for this thread.
				lpGlobals = (SiGlobalStruct*) TlsGetValue(gdwTlsIndex);

				if (lpGlobals != NULL)
					LocalFree((HLOCAL) lpGlobals);
			}
			break;

		// DLL unload due to process termination or FreeLibrary.
		case DLL_PROCESS_DETACH:
			{
				// Release the allocated memory for this thread.
				lpGlobals = (SiGlobalStruct*) TlsGetValue(gdwTlsIndex);

				if (lpGlobals != NULL)
					LocalFree((HLOCAL) lpGlobals);

				// Release the TLS index.
				TlsFree(gdwTlsIndex);
			}
			break;
    }

    return TRUE;
}


//------------------------------------------------------------------------
// SI_GetNumDevices()
//
// Determine number of SiLabs devices connected to the system from the
// registry.
//------------------------------------------------------------------------
SI_USB_XP_API
SI_STATUS 
WINAPI 
SI_GetNumDevices(LPDWORD lpdwNumDevices)
{
	SI_STATUS	status	= SI_DEVICE_NOT_FOUND;
	
	// Validate parameter
	if (!ValidParam(lpdwNumDevices))
	{
		return SI_INVALID_PARAMETER;
	}

	DWORD NumDevices = 0;
	
	HKEY hKeyActiveDrivers;
	HKEY hKeyDriverEntry;
	
	DWORD i = 0;
	
	wchar_t keyName[255];
	DWORD keyNameLength = 255;
	
	BYTE deviceName[12];
	DWORD deviceNameLength = 12;

	// Open HKLM\Drivers\Active to get the list of all active devices and drivers
	// in the system
	// NOTE: This function will loop through the most recent entries to least recent
	// entries (device 0 will always be the last plugged in, device n will be the first)
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("Drivers\\Active"), 0, 0, &hKeyActiveDrivers) == ERROR_SUCCESS)
	{
		// Loop through each one until success is not seen and get the sub-key
		while (RegEnumKeyEx(hKeyActiveDrivers, i, keyName, &keyNameLength, 0, NULL, NULL, NULL) == ERROR_SUCCESS)
		{
			// Look at the device name in that subkey
			if (RegOpenKeyEx(hKeyActiveDrivers, keyName, 0, 0, &hKeyDriverEntry) == ERROR_SUCCESS)
			{
				// If the device name has a prefix of SIX, it is a USBXpress device
				if (RegQueryValueEx(hKeyDriverEntry, _T("Name"), NULL, NULL, deviceName, &deviceNameLength) == ERROR_SUCCESS)
				{				
					if (memcmp(deviceName, _T("SIX"), 6) == 0)
					{
						// Increment the number of devices by 1
						NumDevices++;
					}
				}
			}

			// Close the opened driver key
			RegCloseKey(hKeyDriverEntry);

			// Reset the key name length and increment our index
			keyNameLength = 255;
			i++;
		}

		// Finally close the main key
		RegCloseKey(hKeyActiveDrivers);
	}
	else
	{
		return SI_SYSTEM_ERROR_CODE;
	}

	if (NumDevices > 0)
	{
		status = SI_SUCCESS;
	}

	*lpdwNumDevices = NumDevices;
	return status;
}

//------------------------------------------------------------------------
// SI_GetProductString()
//
// Find the product string of a device by index in the registry.
//------------------------------------------------------------------------
SI_USB_XP_API
SI_STATUS 
WINAPI 
SI_GetProductString(DWORD dwDeviceNum, LPVOID lpvDeviceString, DWORD dwFlags)
{
	SI_STATUS status = SI_SUCCESS;
	DWORD ctrlCode = 0x00;
	DWORD numDevices;
	DWORD deviceIndex;
	HKEY hKeyActiveDrivers;
	HKEY hKeyDriverEntry;
	DWORD i = 0;
	wchar_t keyName[255];
	DWORD keyNameLength = 255;	
	BYTE deviceName[12];
	DWORD deviceNameLength = 12;
	DWORD sixIndex = 0;
	DWORD registryStringLength = 255;

	// Since the devices are listed in reverse, get the number of devices and
	// loop backwards to find the device specified
	SI_GetNumDevices(&numDevices);
	deviceIndex = numDevices - dwDeviceNum;

	// Open HKLM\Drivers\Active to get the list of all active devices and drivers
	// in the system
	// NOTE: This function will loop through the most recent entries to least recent
	// entries (device 0 will always be the last plugged in, device n will be the first)
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("Drivers\\Active"), 0, 0, &hKeyActiveDrivers) == ERROR_SUCCESS)
	{
		// Loop through each one until success is not seen and get the sub-key
		while (RegEnumKeyEx(hKeyActiveDrivers, i, keyName, &keyNameLength, 0, NULL, NULL, NULL) == ERROR_SUCCESS)
		{
			// Look at the device name in that subkey
			if (RegOpenKeyEx(hKeyActiveDrivers, keyName, 0, 0, &hKeyDriverEntry) == ERROR_SUCCESS)
			{
				// If the device name has a prefix of SIX, it is a USBXpress device
				if (RegQueryValueEx(hKeyDriverEntry, _T("Name"), NULL, NULL, deviceName, &deviceNameLength) == ERROR_SUCCESS)
				{					
					if (memcmp(deviceName, _T("SIX"), 6) == 0) 
					{
						sixIndex++;

						if (sixIndex == deviceIndex)
						{
							// If the handle is valid, determine the type of string to return
							switch (dwFlags)
							{
							case SI_RETURN_SERIAL_NUMBER	:	if (RegQueryValueEx(hKeyDriverEntry, _T("SerialString"), NULL, NULL, (LPBYTE)lpvDeviceString, &registryStringLength) == ERROR_SUCCESS)
																{
																	status = SI_SUCCESS;
																}
																break;
							case SI_RETURN_DESCRIPTION		:	if (RegQueryValueEx(hKeyDriverEntry, _T("ProductString"), NULL, NULL, (LPBYTE)lpvDeviceString, &registryStringLength) == ERROR_SUCCESS)
																{
																	status = SI_SUCCESS;
																}
																break;
							case SI_RETURN_VID				:	if (RegQueryValueEx(hKeyDriverEntry, _T("VIDString"), NULL, NULL, (LPBYTE)lpvDeviceString, &registryStringLength) == ERROR_SUCCESS)
																{
																	status = SI_SUCCESS;
																}
																break;
							case SI_RETURN_PID				:	if (RegQueryValueEx(hKeyDriverEntry, _T("PIDString"), NULL, NULL, (LPBYTE)lpvDeviceString, &registryStringLength) == ERROR_SUCCESS)
																{
																	status = SI_SUCCESS;
																}
																break;
							default							:	status = SI_INVALID_PARAMETER;
																break;
							}
						}
					}
				}
			}

			// Close the opened driver key
			RegCloseKey(hKeyDriverEntry);

			// Reset the key name length and increment our index
			keyNameLength = 255;
			i++;
		}

		// Finally close the main key
		RegCloseKey(hKeyActiveDrivers);
	}
	else
	{
		return SI_SYSTEM_ERROR_CODE;
	}

	return status;
}

//------------------------------------------------------------------------
// SI_Open()
//
// Open a file handle to access a SiLabs device by index number.  The open
// routine determines the device's full name and uses it to open the handle.
//------------------------------------------------------------------------
SI_USB_XP_API
SI_STATUS 
WINAPI 
SI_Open(DWORD dwDevice, HANDLE* cyHandle)
{
	SI_STATUS	status = SI_DEVICE_NOT_FOUND;
	HANDLE hFile = INVALID_HANDLE_VALUE;
	DWORD numDevices;
	DWORD deviceIndex;
	HKEY hKeyActiveDrivers;
	HKEY hKeyDriverEntry;
	DWORD i = 0;
	wchar_t keyName[255];
	DWORD keyNameLength = 255;	
	BYTE deviceName[12];
	DWORD deviceNameLength = 12;
	DWORD sixIndex = 0;
	
	// Validate parameter
	if (!ValidParam(cyHandle))
	{
		return SI_INVALID_PARAMETER;
	}

	if (cyHandle)
	{
		// Since the devices are listed in reverse, get the number of devices and
		// loop backwards to find the device specified
		SI_GetNumDevices(&numDevices);
		deviceIndex = numDevices - dwDevice;

		// Open HKLM\Drivers\Active to get the list of all active devices and drivers
		// in the system
		// NOTE: This function will loop through the most recent entries to least recent
		// entries (device 0 will always be the last plugged in, device n will be the first)
		if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("Drivers\\Active"), 0, 0, &hKeyActiveDrivers) == ERROR_SUCCESS)
		{
			// Loop through each one until success is not seen and get the sub-key
			while ((RegEnumKeyEx(hKeyActiveDrivers, i, keyName, &keyNameLength, 0, NULL, NULL, NULL) == ERROR_SUCCESS) && (hFile == INVALID_HANDLE_VALUE))
			{
				// Look at the device name in that subkey
				if (RegOpenKeyEx(hKeyActiveDrivers, keyName, 0, 0, &hKeyDriverEntry) == ERROR_SUCCESS)
				{
					// If the device name has a prefix of SIX, it is a USBXpress device
					if (RegQueryValueEx(hKeyDriverEntry, _T("Name"), NULL, NULL, deviceName, &deviceNameLength) == ERROR_SUCCESS)
					{						
						if (memcmp(deviceName, _T("SIX"), 6) == 0) 
						{
							sixIndex++;

							if (sixIndex == deviceIndex)
							{
								hFile = CreateFile ((LPCWSTR)deviceName, // Open the device SIXn
											  GENERIC_READ | GENERIC_WRITE,	// Open for read/write access
											  NULL,						// Do Not Share
											  NULL,						// No security
											  OPEN_EXISTING,			// Existing file only
											  FILE_ATTRIBUTE_NORMAL,	// Normal file
											  NULL);					// No template file
							}
						}
					}
				}

				// Close the opened driver key
				RegCloseKey(hKeyDriverEntry);

				// Reset the key name length and increment our index
				keyNameLength = 255;
				i++;
			}

			// Finally close the main key
			RegCloseKey(hKeyActiveDrivers);
		}
		else
		{
			return SI_SYSTEM_ERROR_CODE;
		}

		if (hFile == INVALID_HANDLE_VALUE)
		{
			return SI_DEVICE_NOT_FOUND;
		}
		
		*cyHandle = hFile;
		status = SI_SUCCESS;
	}
	else
	{
		status = SI_INVALID_HANDLE;
	}

	return status;
}


//------------------------------------------------------------------------
// SI_Close()
//
// Close file handle used to access a SiLabs device.
//------------------------------------------------------------------------
SI_USB_XP_API
SI_STATUS 
WINAPI 
SI_Close(HANDLE cyHandle)
{
	SI_STATUS	status = SI_INVALID_HANDLE;
	BOOL closeStatus;

	if ((cyHandle != NULL) && (cyHandle != INVALID_HANDLE_VALUE))
	{
		// 9/9/04 this is now implemented in the driver to allow
		// for the surprise remove condition
		//status = SI_InterfaceDisable(cyHandle);
		closeStatus = CloseHandle(cyHandle);

		if(closeStatus)
			status = SI_SUCCESS;
	}

	return status;
}


//------------------------------------------------------------------------
// SI_Read()
//
// Read data from USB device.
// If read timeout value has been set, check RX queue until SI_RX_COMPLETE
// flag bit is set.  If timeout the occurs before SI_RX_COMPLETE, return
// error.  If no timeout has been set attempt read immediately. 
//------------------------------------------------------------------------
SI_USB_XP_API
SI_STATUS 
WINAPI 
SI_Read(HANDLE cyHandle, 
		LPVOID lpBuffer, 
		DWORD dwBytesToRead, 
		LPDWORD lpdwBytesReturned
		)
{
	SI_STATUS			status	 = SI_INVALID_HANDLE;
	SiGlobalStruct*	pGlobals = ThreadGlobalData();

	// Validate parameters
	if (!ValidParam(lpBuffer, lpdwBytesReturned))
	{
		return SI_INVALID_PARAMETER;
	}

	if (pGlobals != NULL)
	{
		// Check for a valid Handle value
		if (cyHandle != INVALID_HANDLE_VALUE)
		{
			// Check that the read length is within range
			if ((dwBytesToRead > 0) && (dwBytesToRead <= SI_MAX_READ_SIZE))
			{
				DWORD	dwNumBytesInQueue	= 0;
				DWORD	dwQueueStatus		= SI_RX_NO_OVERRUN;

				// Init. for no timeout case.
				status = SI_SUCCESS;

				// If timeout set, wait n milliseconds for RX queue to fill.
				// If it does not fill before the timeout, return failure.
				if (pGlobals->dwReadTimeout > 0)
				{
					DWORD	dwStart	= GetTickCount();
					DWORD	dwEnd	= GetTickCount();

					status = SI_CheckRXQueue(cyHandle, &dwNumBytesInQueue, &dwQueueStatus);

					// 10/13/04
					// continue checking the queue until: 
					// 1. timeouts runout or
					// 2. the number of bytes available becomes available or
					// 3. the CheckRXQueue command is unsuccessful
					while(((dwEnd - dwStart) < pGlobals->dwReadTimeout) && (dwNumBytesInQueue < dwBytesToRead) && (status == SI_SUCCESS))
					{
						status = SI_CheckRXQueue(cyHandle, &dwNumBytesInQueue, &dwQueueStatus);
						dwEnd = GetTickCount();
					}

					if ((status == SI_SUCCESS) && (!(dwQueueStatus & SI_RX_READY)))
					{
						status = SI_RX_QUEUE_NOT_READY;
					}
				}

				if (status == SI_SUCCESS)
				{
					// Read transfer packet
					if(!ReadFile(cyHandle, lpBuffer, dwBytesToRead, lpdwBytesReturned, NULL))
					{	
						// Device IO failed.
						status = SI_READ_ERROR;
					}
				}
			}
			else
				status = SI_INVALID_REQUEST_LENGTH;
		}
	}
	else
	{
		status = SI_DEVICE_IO_FAILED;
	}

	return status;
}


//------------------------------------------------------------------------
// SI_Write()
//
// Write data to USB device.
// If write timeout value has been set, continue write attempts until
// successful or timeout occurs.
//------------------------------------------------------------------------
SI_USB_XP_API
SI_STATUS 
WINAPI 
SI_Write(HANDLE cyHandle, 
		 LPVOID lpBuffer, 
		 DWORD dwBytesToWrite, 
		 LPDWORD lpdwBytesWritten
		 )
{
	SI_STATUS			status	 = SI_INVALID_HANDLE;
	SiGlobalStruct*	pGlobals = ThreadGlobalData();

	// Validate parameters
	if (!ValidParam(lpBuffer, lpdwBytesWritten))
	{
		return SI_INVALID_PARAMETER;
	}

	if (pGlobals != NULL)
	{
		if (cyHandle != INVALID_HANDLE_VALUE)
		{
			if ((dwBytesToWrite > 0) && (dwBytesToWrite <= SI_MAX_WRITE_SIZE))
			{
				if (!WriteFile(cyHandle, lpBuffer, dwBytesToWrite, lpdwBytesWritten, NULL))
				{
					status = SI_WRITE_ERROR;

					if (pGlobals->dwWriteTimeout > 0)
					{
						DWORD	dwStart	= GetTickCount();
						DWORD	dwEnd	= GetTickCount();

						// Keep trying to write until success or timeout
						while((dwEnd - dwStart) < pGlobals->dwWriteTimeout && status != SI_SUCCESS)
						{
							if (WriteFile(cyHandle, lpBuffer, dwBytesToWrite, lpdwBytesWritten, NULL))
							{
								status = SI_SUCCESS;	// Write succeeded after > 1 attempts.
							}

							dwEnd = GetTickCount();
						}
					}
				}
				else
					status = SI_SUCCESS;				// Write succeeded on first attempt.
			}
			else
				status = SI_INVALID_REQUEST_LENGTH;
		}
	}
	else
	{
		status = SI_DEVICE_IO_FAILED;
	}

	return status;
}


//------------------------------------------------------------------------
// SI_DeviceIOControl()
//
// Allows calling application take advantage of future IOCTLs or to 
// directly use currently available IOCTLs. 
//------------------------------------------------------------------------
SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_DeviceIOControl(	HANDLE cyHandle, 
						DWORD dwIoControlCode, 
						LPVOID lpInBuffer,
						DWORD dwBytesToRead,
						LPVOID lpOutBuffer, 
						DWORD dwBytesToWrite, 
						LPDWORD lpdwBytesSucceeded)
{
	SI_STATUS	status = SI_INVALID_HANDLE;

	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		if (DeviceIoControl(cyHandle, 
							dwIoControlCode, 
							lpInBuffer,
							dwBytesToRead, 
							lpOutBuffer, 
							dwBytesToWrite,
							lpdwBytesSucceeded,
							NULL))
		{
			status = SI_SUCCESS;
		}
		else
		{
			status = SI_DEVICE_IO_FAILED;
		}
	}

	return status;
}


//------------------------------------------------------------------------
// SI_FlushBuffers()
//------------------------------------------------------------------------
SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_FlushBuffers(HANDLE cyHandle, BYTE FlushTransmit, BYTE FlushReceive)
{
	SI_STATUS	status = SI_INVALID_HANDLE;
	DWORD	dwBytesSent	= 0;

	BYTE Mask = 0x00;
	if(FlushTransmit && FlushReceive)
		Mask = 0x0C;
	else
		if(FlushTransmit)
			Mask = 0x04;
		else
		{
			if(FlushReceive)
				Mask = 0x08;
			else
				return SI_SUCCESS;
		}
	

	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		DWORD dwBytesReturned;				// Ignored

		if(DeviceIoControl(cyHandle,IOCTL_FLUSH_QUEUES, &Mask, sizeof(Mask), NULL, 0, &dwBytesReturned, NULL))
		{
			status = SI_SUCCESS;
		}
	}

	return status;
}


//------------------------------------------------------------------------
// SI_SetTimeouts()
// 
// Sets local timeout values in milliseconds.  
//------------------------------------------------------------------------
SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_SetTimeouts(DWORD dwReadTimeout, DWORD dwWriteTimeout)
{
	SiGlobalStruct*	pGlobals = ThreadGlobalData();

	if (pGlobals != NULL)
	{
		pGlobals->dwReadTimeout	 = dwReadTimeout;
		pGlobals->dwWriteTimeout = dwWriteTimeout;
	}
	else
	{
		return SI_DEVICE_IO_FAILED;
	}

	return SI_SUCCESS;
}


//------------------------------------------------------------------------
// SI_GetTimeouts()
// 
// Gets local timeout values in milliseconds.
//------------------------------------------------------------------------
SI_USB_XP_API 
SI_STATUS	
WINAPI 
SI_GetTimeouts(LPDWORD lpdwReadTimeout, LPDWORD lpdwWriteTimeout)
{
	SiGlobalStruct*	pGlobals = ThreadGlobalData();

	// Validate parameters.
	if (!ValidParam(lpdwReadTimeout, lpdwWriteTimeout))
	{
		return SI_INVALID_PARAMETER;
	}

	if (pGlobals != NULL)
	{
		// Get timeouts
		*lpdwReadTimeout  = pGlobals->dwReadTimeout;
		*lpdwWriteTimeout = pGlobals->dwWriteTimeout;
	}
	else
	{
		return SI_DEVICE_IO_FAILED;
	}

	return SI_SUCCESS;
}


//------------------------------------------------------------------------
// SI_CheckRXQueue()
//
// Check number of bytes and status of RX queue.
// Returns number of bytes in queue in bytes 0 and 1 of buffer.
// Returns queue status in bytes 2 and 3 of buffer.
// Queue status values:
//		SI_RX_NO_OVERRUN	= 0x00
//		SI_RX_OVERRUN		= 0x01
//		SI_RX_READY		= 0x02
//------------------------------------------------------------------------
SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_CheckRXQueue(HANDLE cyHandle, LPDWORD lpdwNumBytesInQueue, LPDWORD lpdwQueueStatus)
{
	SI_STATUS	status			= SI_INVALID_HANDLE;
	DWORD		bytesSucceeded	= 0;
	char		buffer[4];

	// Validate parameters.
	if (!ValidParam(lpdwNumBytesInQueue, lpdwQueueStatus))
	{
		return SI_INVALID_PARAMETER;
	}

	// Check Queue
	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		status = SI_DEVICE_IO_FAILED;		// Initialize status.

		if(DeviceIoControl(cyHandle,IOCTL_CHECK_RX_QUEUE, NULL, 0, buffer, 4, &bytesSucceeded, NULL))
		{
			status = SI_SUCCESS;

			*lpdwNumBytesInQueue	= (DWORD)(buffer[1] & 0x000000FF) | ((buffer[0] << 8) & 0x0000FF00);
			*lpdwQueueStatus		= (DWORD)(buffer[3] & 0x000000FF) | ((buffer[2] << 8) & 0x0000FF00);
		}
	}

	return status;
}



// Serial Commands for the ExpressBridge Interface Start Here 

SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_SetBaudRate(HANDLE cyHandle, 
			   DWORD dwBaudRate
			   )
{
	SI_STATUS	status			= SI_INVALID_HANDLE;
	
	// Set the Baud Rate using the SET_BAUDDIV for now
	// We need to convert the BR to a divisor first
	double BaudDivisorIntPart, BaudDivisortemp, BaudDivisorFractionalPart;

	if (dwBaudRate <= 0)
		return SI_INVALID_BAUDRATE;

	BaudDivisortemp = (3686400/(double)dwBaudRate);
	BaudDivisorFractionalPart = modf(BaudDivisortemp, &BaudDivisorIntPart);

	if (BaudDivisorFractionalPart >= 0.5)
		BaudDivisortemp = ceil(BaudDivisortemp);
	else
		BaudDivisortemp = floor(BaudDivisortemp);

	if ((BaudDivisortemp < 1) || (BaudDivisortemp > 65535))
		return SI_INVALID_BAUDRATE;
	
	USHORT BaudDivisor = (USHORT)(BaudDivisortemp);

	status = SI_SetBaudDivisor(cyHandle, BaudDivisor);

	return status;	
}


SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_GetBaudRate(HANDLE cyHandle,	
			   LPDWORD lpdwBaudRate
			   )
{
	LPWORD lpwBaudDivisor = new WORD;

	// Validate parameters.
	if (!ValidParam(lpdwBaudRate))
	{
		return SI_INVALID_PARAMETER;
	}

	SI_STATUS status = SI_GetBaudDivisor(cyHandle, lpwBaudDivisor);

	if(!status)
	{
		// The divisor does not necessarily directly correspond 
		// to the actual baud rate so look up the Alias
		*lpdwBaudRate = LookupBaudRateAlias(lpwBaudDivisor);
		delete lpwBaudDivisor;
		return status;
	}
	else
	{
		delete lpwBaudDivisor;
		return status;
	}
}


SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_SetBaudDivisor(HANDLE cyHandle,
				  WORD wBaudDivisor
				  )
{
	SI_STATUS	status			= SI_INVALID_HANDLE;

	// Set the Baud Divisor using the SET_BAUDDIV
	BYTE	setup[CP2101_MAX_SETUP_LENGTH];
	DWORD	dwBytesSent	= 0;
	bool ValidDivisor = FALSE;

	memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

	setup[0]	= 0x00;
	setup[1]	= SI_SET_BAUDDIV;					// Set BaudDivisor command
	setup[2]    = UCHAR(wBaudDivisor);					// Baud Divisor value
	setup[3]	= UCHAR(wBaudDivisor>>8);
	setup[4]	= 0x00;		
	setup[5]	= 0x00;	
	setup[6]	= 0x00;
	setup[7]	= 0x00;

	status = SendSetup(cyHandle, setup, 8, &dwBytesSent);

	return status;
}

SI_STATUS
SI_GetBaudDivisor(HANDLE cyHandle, 
				  LPWORD lpwBaudDivisor
				  )
{
	// Send the GET_BAUDDIV command
	// Retrieve current states of the RS-232 modem control lines
	SI_STATUS	status			= SI_INVALID_HANDLE;
	// set buffer length to setup plus one since we're getting a data byte back
	BYTE	setup[CP2101_MAX_SETUP_LENGTH];
	DWORD	dwBytesSent	= 0;

	// Validate parameters.
	if (!ValidParam(lpwBaudDivisor))
	{
		return SI_INVALID_PARAMETER;
	}

	// format the setup packet
	memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

	setup[0]	= 0x00;
	setup[1]	= SI_GET_BAUDDIV;					// Get Baud Divisor command
	setup[2]    = 0x00;					
	setup[3]	= 0x00;
	setup[4]	= 0x00;		
	setup[5]	= 0x00;	
	setup[6]	= 0x02;
	setup[7]	= 0x00;

	status = GetSetup(cyHandle, setup, 10, &dwBytesSent);

	if(status == SI_SUCCESS)
	{
		*(PUCHAR)lpwBaudDivisor = setup[8];
		*((PUCHAR)lpwBaudDivisor+1) = setup[9];
	}

	return status;
}


SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_SetLineControl(HANDLE cyHandle, WORD wLineControl)
{
	// Set the SET_LINE_CTL IOCTL command
	SI_STATUS	status			= SI_INVALID_HANDLE;
	BYTE	setup[CP2101_MAX_SETUP_LENGTH];
	DWORD	dwBytesSent	= 0;

	// to do: validate values

	// We should add error checking to this by means of probing the capabilities of the device
	// use MCCI_GET_PROPS command to get the capabilites
	
	// Send the line control settings
	memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

	setup[0]	= 0x00;
	setup[1]	= SI_SET_LINE_CTL;					// Set Line Control command
	setup[2]    = UCHAR(wLineControl);					// Baud Divisor value
	setup[3]	= UCHAR(wLineControl>>8);
	setup[4]	= 0x00;		
	setup[5]	= 0x00;	
	setup[6]	= 0x00;
	setup[7]	= 0x00;

	status = SendSetup(cyHandle, setup, 8, &dwBytesSent);
	if(status == SI_SUCCESS)
	{
		return SI_SUCCESS;
	}
	else
		return status;

	return status;

}

SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_SetBreak(HANDLE cyHandle, WORD wBreakState)
{
	// Set the SET_LINE_CTL IOCTL command
	SI_STATUS	status			= SI_INVALID_HANDLE;
	BYTE	setup[CP2101_MAX_SETUP_LENGTH];
	DWORD	dwBytesSent	= 0;

	// to do: validate values

	// We should add error checking to this by means of probing the capabilities of the device
	// use MCCI_GET_PROPS command to get the capabilites
	
	// Send the line control settings
	memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

	setup[0]	= 0xC0;
	setup[1]	= SI_SET_BREAK;					// Set Line Control command
	setup[2]    = UCHAR(wBreakState);					// Break state value
	setup[3]	= UCHAR(wBreakState>>8);
	setup[4]	= 0x00;		
	setup[5]	= 0x00;	
	setup[6]	= 0x00;
	setup[7]	= 0x00;

	status = SendSetup(cyHandle, setup, 8, &dwBytesSent);
	if(status == SI_SUCCESS)
	{
		return SI_SUCCESS;
	}
	else
		return status;

	return status;
}


SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_GetLineControl(HANDLE cyHandle, 
				  LPWORD lpwLineControl
				  )
{
	// Send the SET_MHS command
	SI_STATUS	status			= SI_INVALID_HANDLE;
	BYTE	setup[CP2101_MAX_SETUP_LENGTH+2];
	DWORD	dwBytesSent	= 0;

	// Validate parameters.
	if (!ValidParam(lpwLineControl))
	{
		return SI_INVALID_PARAMETER;
	}

	// Send the line control settings
	memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

	setup[0]	= 0x00;
	setup[1]	= SI_GET_LINE_CTL;					// Set Line Control command
	setup[2]    = 0x00;					// Baud Divisor value
	setup[3]	= 0x00;
	setup[4]	= 0x00;		
	setup[5]	= 0x00;	
	setup[6]	= 0x02;
	setup[7]	= 0x00;

	status = GetSetup(cyHandle, setup, 10, &dwBytesSent);
	if(status == SI_SUCCESS)
	{
		*(PUCHAR)lpwLineControl = setup[8];
		*((PUCHAR)lpwLineControl +1) = setup[9];
		return SI_SUCCESS;
	}
	else
		return status;

	return status;

}


// This implementation allows full control of every Flow Control line and the possibility
// of using both hardware and software flow control
// This may be a little harder to setup, but is more configurable


SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_SetFlowControl(HANDLE cyHandle, 
				  BYTE bCTS_MaskCode, 
				  BYTE bRTS_MaskCode, 
				  BYTE bDTR_MaskCode, 
				  BYTE bDSR_MaskCode, 
				  BYTE bDCD_MaskCode, 
				  BOOL bFlowXonXoff
				  )
{	
	SI_STATUS	status	= SI_INVALID_HANDLE;

	// use Setup length plus 16 since we're filling out the flow control structure
	BYTE	setup[CP2101_MAX_SETUP_LENGTH+16];
	memset(setup, 0, (CP2101_MAX_SETUP_LENGTH +15));
	
	DWORD	dwBytesSent	= 0;

	// Check the check for valid mask codes for the Flow Control Lines
	// Do the inputs first 
	if(!(bCTS_MaskCode == SI_STATUS_INPUT || bCTS_MaskCode == SI_HANDSHAKE_LINE))
		return SI_INVALID_PARAMETER;
	if(!(bRTS_MaskCode == SI_HELD_INACTIVE || bRTS_MaskCode == SI_HELD_ACTIVE || bRTS_MaskCode == SI_FIRMWARE_CONTROLLED
		|| bRTS_MaskCode == SI_TRANSMIT_ACTIVE_SIGNAL ))
		return SI_INVALID_PARAMETER;
	if(!(bDTR_MaskCode == SI_HELD_INACTIVE || bDTR_MaskCode == SI_HELD_ACTIVE || bDTR_MaskCode == SI_FIRMWARE_CONTROLLED))
		return SI_INVALID_PARAMETER;
	if(!(bDSR_MaskCode == SI_STATUS_INPUT || bDSR_MaskCode == SI_HANDSHAKE_LINE))
		return SI_INVALID_PARAMETER;
	if(!(bDCD_MaskCode == SI_STATUS_INPUT || bDCD_MaskCode == SI_HANDSHAKE_LINE))
		return SI_INVALID_PARAMETER;

	// Xon Xoff is either on or off, no other settings are currently supported
	if( !((bFlowXonXoff == TRUE) || (bFlowXonXoff == FALSE)))
		return SI_INVALID_PARAMETER;		

	// Convert the Flow Control Structure to the actual bit-wise mapping
	// This data structure is 16 bytes long.

	// start at the beginning with the low bytes
	setup[8] |= bDTR_MaskCode;
	setup[8] |= bCTS_MaskCode << 3;
	setup[8] |= bDSR_MaskCode << 4;
	setup[8] |= bDCD_MaskCode << 5;
	setup[8] |= bDSR_MaskCode << 6;

	setup[12] |= bFlowXonXoff;		// Set SERIAL_AUTO_TRANSMIT
	setup[12] |= bFlowXonXoff << 1;	// Set SERIAL_AUTO_RECEIVE
	setup[12] |= bRTS_MaskCode << 6;	
	
	// The Set Flow command consists of 32 bytes of data corresponding to the Flow Control settings
	// we will now use the input paramters of this function to fill out the structure
		
	// Send the Set Flow command
	// Send the line control settings	
	setup[0]	= 0x00;
	setup[1]	= SI_SET_FLOW;					// Set Flow control command
	setup[2]    = 0x00;					
	setup[3]	= 0x00;
	setup[4]	= 0x00;		
	setup[5]	= 0x00;	
	setup[6]	= 0x10;
	setup[7]	= 0x00;

	status = SendSetup(cyHandle, setup, CP2101_MAX_SETUP_LENGTH + 16, &dwBytesSent);

	return status;
}


SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_GetFlowControl(HANDLE cyHandle, 
				  LPBYTE lpbCTS_MaskCode, 
				  LPBYTE lpbRTS_MaskCode, 
				  LPBYTE lpbDTR_MaskCode, 
				  LPBYTE lpbDSR_MaskCode, 
				  LPBYTE lpbDCD_MaskCode, 
				  LPBYTE lpbFlowXonXoff
				  )
{
	SI_STATUS	status	= SI_INVALID_HANDLE;

	// Validate parameters.
	if (!ValidParam(lpbCTS_MaskCode))
	{
		return SI_INVALID_PARAMETER;
	}
	if (!ValidParam(lpbRTS_MaskCode))
	{
		return SI_INVALID_PARAMETER;
	}
	if (!ValidParam(lpbDTR_MaskCode))
	{
		return SI_INVALID_PARAMETER;
	}
	if (!ValidParam(lpbDSR_MaskCode))
	{
		return SI_INVALID_PARAMETER;
	}
	if (!ValidParam(lpbDCD_MaskCode))
	{
		return SI_INVALID_PARAMETER;
	}
	if (!ValidParam(lpbFlowXonXoff))
	{
		return SI_INVALID_PARAMETER;
	}

	// use Setup length plus 16 since we're filling out the flow control structure
	BYTE	setup[CP2101_MAX_SETUP_LENGTH+16];
	memset(setup, 0, (CP2101_MAX_SETUP_LENGTH +15));

	DWORD	dwBytesSent	= 0;

	// The Set Flow command consists of 32 bytes of data corresponding to the Flow Control settings
	// we will now use the input paramters of this function to fill out the structure
		
	// Send the Set Flow command
	// Send the line control settings	
	setup[0]	= 0x00;
	setup[1]	= SI_GET_FLOW;					// Set Flow control command
	setup[2]    = 0x00;					
	setup[3]	= 0x00;
	setup[4]	= 0x00;		
	setup[5]	= 0x00;	
	setup[6]	= 0x10;
	setup[7]	= 0x00;

	status = GetSetup(cyHandle, setup, CP2101_MAX_SETUP_LENGTH + 16, &dwBytesSent);
	if(status == SI_SUCCESS)
	{
		// Convert the bit-wise mapping to the Flow Control Structure 
		// This data structure is 16 bytes long.

		// start at the beginning with the low bytes
		*lpbDTR_MaskCode = (setup[8] & 0x03); // bits zero and one
		*lpbCTS_MaskCode = (setup[8] & 0x08) >> 3;	// bit three
		*lpbDSR_MaskCode = (setup[8] & 0x10) >>4; // bit four
		*lpbDCD_MaskCode = (setup[8] & 0x20) >>5;	// bit five
		*lpbDSR_MaskCode = (setup[8] & 0x40) >>6; // bit six

		*lpbFlowXonXoff = ((setup[12] & 0x01) && (setup[12] & 0x02)); // both bits zero and one need to be set
		*lpbRTS_MaskCode = (setup[12] & 0xC0) >>6;	// bit six
	}

	return status;
}


SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_GetModemStatus (HANDLE cyHandle, 
				   PBYTE ModemStatus
				   )
{
	SI_STATUS	status			= SI_INVALID_HANDLE;
	BYTE	setup[CP2101_MAX_SETUP_LENGTH];
	DWORD	dwBytesSent	= 0;

	// bits 0 through 7 of the Value set the index
	// and bits 8 through 15 specify the character value

	// Xon
	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

		setup[0]	= 0x00;
		setup[1]	= SI_GET_MDMSTS;// Enable/Disable Interface Command
		setup[2]    = 0x00;			// Value should be anything other than
		setup[3]	= 0x00;			// zero to enable the interface
		setup[4]	= 0x00;		
		setup[5]	= 0x00;	
		setup[6]	= 0x01;
		setup[7]	= 0x00;

		status = GetSetup(cyHandle, setup, 9, &dwBytesSent);

		if (status == SI_SUCCESS)
		{
			*ModemStatus = setup[8];
		}

	}
	
	return status;
}

SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_ReadLatch (HANDLE cyHandle, 
			   LPBYTE Latch
			   )
{
	SI_STATUS	status			= SI_INVALID_HANDLE;
	BYTE	setup[CP2101_MAX_SETUP_LENGTH];
	DWORD	dwBytesSent	= 0;

	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

		setup[0]	= 0xC0;
		setup[1]	= 0xFF;
		setup[2]    = 0xC2;
		setup[3]	= 0x00;			// zero to enable the interface
		setup[4]	= 0x00;		
		setup[5]	= 0x00;	
		setup[6]	= 0x01;
		setup[7]	= 0x00;

		status = GetSetup(cyHandle, setup, 9, &dwBytesSent);

		if (status == SI_SUCCESS)
		{
			*Latch = setup[8];
		}

	}
	
	return status;
}

SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_WriteLatch (HANDLE cyHandle, 
			   BYTE	bMask,
			   BYTE bLatch
			   )
{
	SI_STATUS	status			= SI_INVALID_HANDLE;
	BYTE	setup[CP2101_MAX_SETUP_LENGTH];
	DWORD	dwBytesSent	= 0;

	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

		setup[0]	= 0x40;
		setup[1]	= 0xFF;
		setup[2]    = 0xE1;
		setup[3]	= 0x37;
		setup[4]	= bMask;
		setup[5]	= bLatch;
		setup[6]	= 0x00;
		setup[7]	= 0x00;

		status = SendSetup(cyHandle, setup, 8, &dwBytesSent);
	}
	
	return status;
}

//------------------------------------------------------------------------
// CP210x_GetPortConfig()
//
// Gets the current port latch value from the device
// 
//------------------------------------------------------------------------
SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_GetPortConfig(	HANDLE cyHandle,
						PORT_CONFIG*	PortConfig)
{
	SI_STATUS status = SI_INVALID_HANDLE;
	BYTE	setup[CP2101_MAX_SETUP_LENGTH];
	DWORD	dwBytesSent	= 0;

	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

		setup[0]	= 0xC0;
		setup[1]	= 0xFF;
		setup[2]    = 0x0C;
		setup[3]	= 0x37;
		setup[4]	= 0x00;
		setup[5]	= 0x00;
		setup[6]	= 0x0D;
		setup[7]	= 0x00;

		status = GetSetup(cyHandle, setup, 8 + 13, &dwBytesSent);

		if (status == SI_SUCCESS)
		{
			PortConfig->Mode = (setup[8] << 8) + setup[9];
			//PortConfig->Reset.LowPower = (setup[10] << 8) + setup[11];
			PortConfig->Reset_Latch = (setup[12] << 8) + setup[13];
			//PortConfig->Suspend.Mode = (setup[14] << 8) + setup[15];
			//PortConfig->Suspend.LowPower = (setup[16] << 8) + setup[17];
			PortConfig->Suspend_Latch = (setup[18] << 8) + setup[19];
			PortConfig->EnhancedFxn = setup[20];

			// Mask out reserved bits in EnhancedFxn
			PortConfig->EnhancedFxn &= ~(EF_RESERVED_0 | EF_RESERVED_1);
		}
	}

	return status;
}

//------------------------------------------------------------------------
// CP210x_SetPortConfig()
//
// Sets the port pin configuration for the CP201x device
// 
//------------------------------------------------------------------------
SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_SetPortConfig(	HANDLE cyHandle,
						PORT_CONFIG*	PortConfig)
{
	SI_STATUS status = SI_INVALID_HANDLE;
	BYTE	setup[CP2101_MAX_SETUP_LENGTH];
	DWORD	dwBytesSent	= 0;
	BYTE	Temp_EnhancedFxn;

	// Change user Port_Config structure to match firmware, and check reserved bits are zero
	if (PortConfig->EnhancedFxn & (EF_RESERVED_0 | EF_RESERVED_1))
		return SI_INVALID_PARAMETER;

	Temp_EnhancedFxn = PortConfig->EnhancedFxn; // save user settings into temp variable to send out
	
	if (Temp_EnhancedFxn & EF_WEAKPULLUP)
	{
		Temp_EnhancedFxn |= 0x30; // Set both Weak Pullup bits
	}
	else
	{
		Temp_EnhancedFxn &= ~0x30; // Clear both Weak Pullup bits
	}
														
	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

		setup[0]	= 0x40;
		setup[1]	= 0xFF;
		setup[2]    = 0x0C;
		setup[3]	= 0x37;
		setup[4]	= 0x00;
		setup[5]	= 0x00;
		setup[6]	= 0x0D;
		setup[7]	= 0x00;
		setup[8] = 	(PortConfig->Mode & 0xFF00) >> 8;
		setup[9] = 	(PortConfig->Mode & 0x00FF);
		setup[10] = 0x00;	//(PortConfig->Reset.LowPower & 0xFF00) >> 8;
		setup[11] = 0x00;	//(PortConfig->Reset.LowPower & 0x00FF);
		setup[12] = (PortConfig->Reset_Latch & 0xFF00) >> 8;
		setup[13] = (PortConfig->Reset_Latch & 0x00FF);
		setup[14] = (PortConfig->Mode & 0xFF00) >> 8;
		setup[15] = (PortConfig->Mode & 0x00FF);
		setup[16] = 0x00;	//(PortConfig->Suspend.LowPower & 0xFF00) >> 8;
		setup[17] = 0x00;	//(PortConfig->Suspend.LowPower & 0x00FF);
		setup[18] = (PortConfig->Suspend_Latch & 0xFF00) >> 8;
		setup[19] = (PortConfig->Suspend_Latch & 0x00FF);
		setup[20] = Temp_EnhancedFxn;
		


		status = SendSetup(cyHandle, setup, 21, &dwBytesSent);
		
	}

	return status;
}

SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_Set_Chars(HANDLE cyHandle, 
			 BYTE bXon, 
			 BYTE bXoff, 
			 BYTE bEOF, 
			 BYTE bErrorReceived, 
			 BYTE bBreakReceived, 
			 BYTE bSpecialEvent
			 )
{
	SI_STATUS	status			= SI_INVALID_HANDLE;
	BYTE	setup[CP2101_MAX_SETUP_LENGTH];
	DWORD	dwBytesSent	= 0;

	// bits 0 through 7 of the Value set the index
	// and bits 8 through 15 specify the character value

	// Xon
	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

		setup[0]	= 0x00;
		setup[1]	= SI_SET_CHAR;		// Enable/Disable Interface Command
		setup[2]    = 0x04;		// Value should be anything other than
		setup[3]	= bXon;		// zero to enable the interface
		setup[4]	= 0x00;		
		setup[5]	= 0x00;	
		setup[6]	= 0x00;
		setup[7]	= 0x00;

		status = SendSetup(cyHandle, setup, 8, &dwBytesSent);
		if(status != SI_SUCCESS)
			return status;
	}
	
	// Xoff
	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

		setup[0]	= 0x00;
		setup[1]	= SI_SET_CHAR;		// Enable/Disable Interface Command
		setup[2]    = 0x05;		// Value should be anything other than
		setup[3]	= bXoff;		// zero to enable the interface
		setup[4]	= 0x00;		
		setup[5]	= 0x00;	
		setup[6]	= 0x00;
		setup[7]	= 0x00;

		status = SendSetup(cyHandle, setup, 8, &dwBytesSent);
		if(status != SI_SUCCESS)
			return status;
	}

	// EOF
	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

		setup[0]	= 0x00;
		setup[1]	= SI_SET_CHAR;		// Enable/Disable Interface Command
		setup[2]    = 0x00;		// Value should be anything other than
		setup[3]	= bEOF;		// zero to enable the interface
		setup[4]	= 0x00;		
		setup[5]	= 0x00;	
		setup[6]	= 0x00;
		setup[7]	= 0x00;

		status = SendSetup(cyHandle, setup, 8, &dwBytesSent);
		if(status != SI_SUCCESS)
			return status;
	}

	// Error Received
	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

		setup[0]	= 0x00;
		setup[1]	= SI_SET_CHAR;		// Enable/Disable Interface Command
		setup[2]    = 0x01;		// Value should be anything other than
		setup[3]	= bErrorReceived;		// zero to enable the interface
		setup[4]	= 0x00;		
		setup[5]	= 0x00;	
		setup[6]	= 0x00;
		setup[7]	= 0x00;

		status = SendSetup(cyHandle, setup, 8, &dwBytesSent);
		if(status != SI_SUCCESS)
			return status;
	}

	// Break Received
	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

		setup[0]	= 0x00;
		setup[1]	= SI_SET_CHAR;		// Enable/Disable Interface Command
		setup[2]    = 0x02;		// Value should be anything other than
		setup[3]	= bBreakReceived;		// zero to enable the interface
		setup[4]	= 0x00;		
		setup[5]	= 0x00;	
		setup[6]	= 0x00;
		setup[7]	= 0x00;

		status = SendSetup(cyHandle, setup, 8, &dwBytesSent);
		if(status != SI_SUCCESS)
			return status;
	}

	// Special Event
	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

		setup[0]	= 0x00;
		setup[1]	= SI_SET_CHAR;		// Enable/Disable Interface Command
		setup[2]    = 0x03;		// Value should be anything other than
		setup[3]	= bSpecialEvent;		// zero to enable the interface
		setup[4]	= 0x00;		
		setup[5]	= 0x00;	
		setup[6]	= 0x00;
		setup[7]	= 0x00;

		status = SendSetup(cyHandle, setup, 8, &dwBytesSent);
		if(status != SI_SUCCESS)
			return status;
	}
	
	return status;

}

SI_USB_XP_API
SI_STATUS	
WINAPI 
SI_Get_Chars(HANDLE cyHandle, 
			 LPBYTE lpbXon, 
			 LPBYTE lpbXoff, 
			 LPBYTE lpbEOF, 
			 LPBYTE lpbErrorReceived, 
			 LPBYTE lpbBreakReceived, 
			 LPBYTE lpbSpecialEvent
			 )
{
	SI_STATUS	status			= SI_INVALID_HANDLE;
	BYTE	setup[CP2101_MAX_SETUP_LENGTH];
	DWORD	dwBytesSent	= 0;
	
	// Validate parameters.
	if (!ValidParam(lpbXon))
	{
		return SI_INVALID_PARAMETER;
	}
	if (!ValidParam(lpbXoff))
	{
		return SI_INVALID_PARAMETER;
	}
	if (!ValidParam(lpbEOF))
	{
		return SI_INVALID_PARAMETER;
	}
	if (!ValidParam(lpbErrorReceived))
	{
		return SI_INVALID_PARAMETER;
	}
	if (!ValidParam(lpbBreakReceived))
	{
		return SI_INVALID_PARAMETER;
	}
	if (!ValidParam(lpbSpecialEvent))
	{
		return SI_INVALID_PARAMETER;
	}	
	
	// bits 0 through 7 of the Value set the index
	// and bits 8 through 15 specify the character value

	// Xon
	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		memset(setup, 0, CP2101_MAX_SETUP_LENGTH);

		setup[0]	= 0x00;
		setup[1]	= SI_GET_CHAR;		// Enable/Disable Interface Command
		setup[2]    = 0x00;		// Value should be anything other than
		setup[3]	= 0x00;		// zero to enable the interface
		setup[4]	= 0x00;		
		setup[5]	= 0x00;	
		setup[6]	= 0x06;
		setup[7]	= 0x00;

		status = GetSetup(cyHandle, setup, 14, &dwBytesSent);
		if(status == SI_SUCCESS)
		{
			*lpbEOF				= setup[8];
			*lpbErrorReceived	= setup[9];
			*lpbBreakReceived	= setup[10];
			*lpbSpecialEvent	= setup[11];
			*lpbXon				= setup[12];
			*lpbXoff			= setup[13];
		}
	}

	return status;

}


//------------------------------------------------------------------------
// SendSetup()
//
// Allows calling application to send a setup buffer.
//
// LPVOID	lpSetupBuffer	- Setup buffer.
// DWORD	dwBytesToSend	- size of setup buffer.
//------------------------------------------------------------------------
static SI_STATUS	 SendSetup(	HANDLE	cyHandle, 
								LPVOID	lpSetupBuffer,
								DWORD	dwBytesToSend,
								LPDWORD	lpdwBytesSent)
{
	SI_STATUS status = SI_INVALID_HANDLE;

	// Validate parameters
	if (!ValidParam(lpSetupBuffer, lpdwBytesSent))
	{
		return SI_INVALID_PARAMETER;
	}

	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		if (DeviceIoControl(cyHandle, IOCTL_USB_SEND_CONTROL_REQUEST, lpSetupBuffer, dwBytesToSend, lpSetupBuffer, dwBytesToSend, lpdwBytesSent, NULL))
		{
			status = SI_SUCCESS;
		}
		else
		{
			status = SI_DEVICE_IO_FAILED;
		}
	}

	return status;
}




//------------------------------------------------------------------------
// GetSetup()
//
// Allows calling application to retrieve a setup buffer.
//
// LPVOID	lpSetupBuffer	- Setup buffer.
// DWORD	dwBytesToSend	- size of setup buffer.
//------------------------------------------------------------------------
static SI_STATUS	GetSetup(	HANDLE	cyHandle, 
								LPVOID	lpSetupBuffer,
								DWORD	dwBytesToSend,
								LPDWORD	lpdwBytesSent)
{
	SI_STATUS status = SI_INVALID_HANDLE;
	
	// Validate parameters
	if (!ValidParam(lpSetupBuffer, lpdwBytesSent))
	{
		return SI_INVALID_PARAMETER;
	}

	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		if (DeviceIoControl(cyHandle, IOCTL_USB_GET_CONTROL_REQUEST, lpSetupBuffer, dwBytesToSend, lpSetupBuffer, 10, lpdwBytesSent, NULL))
		{
			status = SI_SUCCESS;
		}
		else
		{
			status = SI_DEVICE_IO_FAILED;

			DWORD err = GetLastError();
		}
	}
	
	return status;
}

//------------------------------------------------------------------------
// ValidParam(LPDWORD)
//
// Checks validity of an LPDWORD pointer value.
//------------------------------------------------------------------------
static BOOL ValidParam(LPDWORD lpdwPointer)
{
	DWORD temp = 0;

	try 
	{
		temp = *lpdwPointer;
	}
	catch(...)
	{
		return FALSE;
	}
	return TRUE;
}

//------------------------------------------------------------------------
// ValidParam(LPWORD)
//
// Checks validity of an LPWORD pointer value.
//------------------------------------------------------------------------
static BOOL ValidParam(LPWORD lpwPointer)
{
	WORD temp = 0;

	try 
	{
		temp = *lpwPointer;
	}
	catch(...)
	{
		return FALSE;
	}
	return TRUE;
}

//------------------------------------------------------------------------
// ValidParam(LPBYTE)
//
// Checks validity of an LPBYTE pointer value.
//------------------------------------------------------------------------
static BOOL ValidParam(LPBYTE lpbPointer)
{
	BYTE temp = 0;

	try 
	{
		temp = *lpbPointer;
	}
	catch(...)
	{
		return FALSE;
	}
	return TRUE;
}

//------------------------------------------------------------------------
// ValidParam(LPVOID)
//
// Checks validity of an LPVOID pointer value.
//------------------------------------------------------------------------
static BOOL ValidParam(LPVOID lpVoidPointer)
{
	BYTE temp = 0;

	try 
	{
		temp = *((BYTE*)lpVoidPointer);
	}
	catch(...)
	{
		return FALSE;
	}
	return TRUE;
}

//------------------------------------------------------------------------
// ValidParam(HANDLE*)
//
// Checks validity of an HANDLE* pointer value.
//------------------------------------------------------------------------
static BOOL ValidParam(HANDLE* lpHandle)
{
	HANDLE temp = 0;

	try 
	{
		temp = *lpHandle;
	}
	catch(...)
	{
		return FALSE;
	}
	return TRUE;
}

//------------------------------------------------------------------------
// ValidParam(LPVOID, LPDWORD)
//
// Checks validity of LPVOID, LPDWORD pair of pointer values.
//------------------------------------------------------------------------
static BOOL ValidParam(LPVOID lpVoidPointer, LPDWORD lpdwPointer)
{
	if (ValidParam(lpVoidPointer))
		if (ValidParam(lpdwPointer))
			return TRUE;

	return FALSE;
}

//------------------------------------------------------------------------
// ValidParam(LPDWORD, LPDWORD)
//
// Checks validity of LPDWORD, LPDWORD pair of pointer values.
//------------------------------------------------------------------------
static BOOL ValidParam(LPDWORD lpdwPointer1, LPDWORD lpdwPointer2)
{
	if (ValidParam(lpdwPointer1))
		if (ValidParam(lpdwPointer2))
			return TRUE;

	return FALSE;
}

static DWORD BRLookupList[64][2] = { {1, 0}, {1, 0}, {2, 1500000}, {2, 1500000}, {3, 1228800}, {3, 1228800}, 
{4, 921600}, {5, 921600}, {6, 576000}, {6, 576000}, {7, 500000}, {7, 500000}, {8, 460800}, {13, 460800}, 
{14, 256000}, {14, 256000}, {15, 250000}, {15, 250000}, {16, 230400}, {23, 230400}, {24, 153600},
{28, 153600}, {29, 128000}, {31, 128000}, {32, 115200}, {47, 115200}, {48, 76800}, {57, 76800}, {58, 64000},
{63, 64000}, {64, 57600}, {65, 57600}, {66, 56000}, {71, 56000}, {72, 51200}, {95, 51200}, {96, 38400},
{127, 38400}, {128, 28800}, {191, 28800}, {192, 19200}, {229, 19200}, {230, 16000}, {255, 16000}, {256, 14400}, 
{383, 14400}, {384, 9600}, {511, 9600}, {512, 7200}, {767, 7200}, {768, 4800}, {921, 4800}, {922, 4000}, 
{1535, 4000}, {1536, 2400}, {2047, 2400}, {2048, 1800}, {3071, 1800}, {3072, 1200}, {6143, 1200}, {6144, 600}, 
{12287, 600}, {12288, 300}, {65535, 300}};

static DWORD LookupBaudRateAlias(LPWORD lpwBaudDivisor)
{
	WORD BaudDivisor = *lpwBaudDivisor;

	for(int i = 0; i <= 64; i++)
	{
		if ((BaudDivisor >= BRLookupList[i][0]) && (BaudDivisor <= BRLookupList[i+1][0]))
		{
			if(BaudDivisor == BRLookupList[i+1][0])
				return BRLookupList[i+1][1];

			return BRLookupList[i][1];
		}
	}

	return 0;
	
}