//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestPanel.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_USBTEST_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDD_SELECT                      129
#define IDD_TESTPANEL_DIALOG            130
#define IDC_BTN_GROUPBOX                1000
#define IDC_LED_GROUPBOX                1001
#define IDC_ANALOG1_GROUPBOX            1002
#define IDC_BTN1_LED                    1004
#define IDC_BTN2_LED                    1005
#define IDC_CHECK_LED1                  1006
#define IDC_CHECK_LED2                  1007
#define IDC_AN1_METER                   1008
#define IDC_P0_B1                       1011
#define IDC_P0_B2                       1012
#define IDC_P0_B3                       1013
#define IDC_P0_B0                       1014
#define IDC_P1_B1                       1016
#define IDC_P1_B3                       1018
#define IDC_P1_B0                       1019
#define IDC_P1_B2                       1020
#define IDC_AN2_METER                   1021
#define IDC_DEVICELIST                  1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
