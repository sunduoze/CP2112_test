Option Strict Off
Option Explicit On
Friend Class frmMain
	Inherits System.Windows.Forms.Form
	
	Private Sub cmdBrowseReceive_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdBrowseReceive.Click
		
		'select the file you want to receive into
		On Error GoTo ErrHandler
		
		CommonDialog1Open.ShowDialog()
		txtReceive.Text = CommonDialog1Open.FileName
		Exit Sub
		
ErrHandler: 
		Exit Sub
		
	End Sub
	
	Private Sub cmdBrowseTransfer_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdBrowseTransfer.Click
		
		'select the file you want to send
		On Error GoTo ErrHandler
		
		CommonDialog1Open.ShowDialog()
		txtTransfer.Text = CommonDialog1Open.FileName
		Exit Sub
		
ErrHandler: 
		Exit Sub
		
	End Sub
	
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		
		Me.Close()
		
	End Sub
	
	Private Sub cmdReceive_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdReceive.Click
		
		Dim readTO As Integer
		Dim writeTO As Integer
		
		'make sure we have devices connected, then open
		'the selected device
		If cmbDevice.SelectedIndex >= 0 Then
            Status = SI_GetTimeouts(readTO, writeTO)
            Status = SI_SetTimeouts(1000, 1000)
			
            Status = SI_Open(cmbDevice.SelectedIndex, hUSBDevice)
			
			'if we can connect to the device, then receive the file
            If Status = SI_SUCCESS Then
                ReadFileData()

                SI_Close(hUSBDevice)

                Status = SI_SetTimeouts(readTO, writeTO)

                hUSBDevice = INVALID_HANDLE_VALUE
            End If
		End If
		
	End Sub
	
	Private Sub cmdTransfer_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdTransfer.Click
		
		Dim readTO As Integer
		Dim writeTO As Integer
		
		'make sure we have devices connected, then open
		'the selected device
		If cmbDevice.SelectedIndex >= 0 Then
            Status = SI_Open(cmbDevice.SelectedIndex, hUSBDevice)
			
			'if we can connect to the device, then send it the file
			'then close the connection to the device
            If Status = SI_SUCCESS Then
                Status = SI_GetTimeouts(readTO, writeTO)
                Status = SI_SetTimeouts(1000, 1000)

                WriteFileData()

                Status = SI_SetTimeouts(readTO, writeTO)

                SI_Close(hUSBDevice)

                hUSBDevice = INVALID_HANDLE_VALUE
            End If
		End If
		
	End Sub
	
	Private Sub cmdUpdateDeviceList_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdUpdateDeviceList.Click
		
		'device number, device string, and temp var newdevstring
		Dim DevNum As Integer
		Dim DevStr(SI_MAX_DEVICE_STRLEN) As Byte
		Dim NewDevStr As String
		Dim i As Short
		
		'clear the combo box
		cmbDevice.Items.Clear()
		
		'determine how many devices are hooked up
        Status = SI_GetNumDevices(DevNum)
		
		'if we find a device, obtain the name of each device
		'and convert the string to a vb string to add to the
		'combo list
        If Status = SI_SUCCESS Then
            For i = 0 To (DevNum - 1)
                Status = SI_GetProductString(i, DevStr(0), SI_RETURN_SERIAL_NUMBER)
                NewDevStr = ConvertToVBString(DevStr)
                cmbDevice.Items.Insert(i, NewDevStr)
            Next

            cmbDevice.SelectedIndex = 0 'then set combo list to first item
        Else
            cmbDevice.SelectedIndex = -1 'otherwise set list to -1
        End If
		
		
	End Sub
	
	
	Private Sub frmMain_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		
		'on open, update the device list
		cmdUpdateDeviceList_Click(cmdUpdateDeviceList, New System.EventArgs())
		
	End Sub
End Class