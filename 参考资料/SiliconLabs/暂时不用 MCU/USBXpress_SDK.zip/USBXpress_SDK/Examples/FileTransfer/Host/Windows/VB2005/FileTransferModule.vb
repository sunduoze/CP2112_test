Option Strict Off
Option Explicit On
Module modFileTransfer
	
	
	' Declare statements for all the functions in the SiUSBXp DLL
	' NOTE: These statements assume that the DLL file is located in
	'       the same directory as this project.
	'       If you change the location of the DLL, be sure to change the location
	'       in the declare statements also.
	Public Declare Function SI_GetNumDevices Lib "SiUSBXp.dll" (ByRef lpwdNumDevices As Integer) As Short
	Public Declare Function SI_GetProductString Lib "SiUSBXp.dll" (ByVal dwDeviceNum As Integer, ByRef lpvDeviceString As Byte, ByVal dwFlags As Integer) As Short
	Public Declare Function SI_Open Lib "SiUSBXp.dll" (ByVal dwDevice As Integer, ByRef cyHandle As Integer) As Short
	Public Declare Function SI_Close Lib "SiUSBXp.dll" (ByVal cyHandle As Integer) As Short
    Public Declare Function SI_Read Lib "SiUSBXp.dll" (ByVal cyHandle As Integer, ByRef lpBuffer As Byte, ByVal dwBytesToRead As Integer, ByRef lpdwBytesReturned As Integer, ByVal lpOverlapped As Integer) As Short
    Public Declare Function SI_Write Lib "SiUSBXp.dll" (ByVal cyHandle As Integer, ByRef lpBuffer As Byte, ByVal dwBytesToWrite As Integer, ByRef lpdwBytesWritten As Integer, ByVal lpOverlapped As Integer) As Short
    Public Declare Function SI_SetTimeouts Lib "SiUSBXp.dll" (ByVal dwReadTimeout As Integer, ByVal dwWriteTimeout As Integer) As Short
    Public Declare Function SI_GetTimeouts Lib "SiUSBXp.dll" (ByRef lpdwReadTimeout As Integer, ByRef lpdwWriteTimeout As Integer) As Short
    Public Declare Function SI_CheckRXQueue Lib "SiUSBXp.dll" (ByVal cyHandle As Integer, ByRef lpdwNumBytesInQueue As Integer, ByRef lpdwQueueStatus As Integer) As Short

    'Masks for the serial number and description
    Public Const SI_RETURN_SERIAL_NUMBER As Short = &H0S
    Public Const SI_RETURN_DESCRIPTION As Short = &H1S
    Public Const SI_RETURN_LINK_NAME As Short = &H2S
    Public Const SI_RETURN_VID As Short = &H3S
    Public Const SI_RETURN_PID As Short = &H4S

    'Masks for return values from the device
    Public Const SI_SUCCESS As Short = &H0S
    Public Const SI_DEVICE_NOT_FOUND As Short = &HFFS
    Public Const SI_INVALID_HANDLE As Short = &H1S
    Public Const SI_READ_ERROR As Short = &H2S
    Public Const SI_RX_QUEUE_NOT_READY As Short = &H3S
    Public Const SI_WRITE_ERROR As Short = &H4S
    Public Const SI_RESET_ERROR As Short = &H5S
    Public Const SI_INVALID_BUFFER As Short = &H6S
    Public Const SI_INVALID_REQUEST_LENGTH As Short = &H7S
    Public Const SI_DEVICE_IO_FAILED As Short = &H8S

    Public Const SI_QUEUE_NO_OVERRUN As Short = &H0S
    Public Const SI_QUEUE_OVERRUN As Short = &H1S
    Public Const SI_QUEUE_READY As Short = &H2S

    Public Const SI_MAX_DEVICE_STRLEN As Short = 256
    Public Const SI_MAX_READ_SIZE As Integer = 65536
    Public Const SI_MAX_WRITE_SIZE As Short = 4096

    Public Const INVALID_HANDLE_VALUE As UInt32 = &HFFFF

    Public Const MAX_PACKET_SIZE_WRITE As Short = 512
    Public Const MAX_PACKET_SIZE_READ As Short = 4096

    Public Const FT_READ_MSG As Short = &H0S
    Public Const FT_WRITE_MSG As Short = &H1S
    Public Const FT_READ_ACK As Short = &H2S
    Public Const FT_MSG_SIZE As Short = &H3S

    Public Const MAX_WRITE_PKTS As Short = 1

    'Variables used within the project
    Public hUSBDevice As UInt32 'global handle that is set when connected with the usb device
    Public Status As Integer 'status, value to set when communicating with the board to determine success
    Public TempString As String 'tempstring, contains the value of the file when performing a read

    Public Const IOBufSize As Short = 12
    Public IOBuf(IOBufSize) As Byte 'io buffer; bits are defined as follows:
    'IOBuf(0) = LED1
    'IOBuf(1) = LED2
    'IOBuf(2) = Port
    'IOBuf(3) = Analog1
    'IOBuf(4) = Analog2
    'IOBuf(5,6,7) = Unused
    'IOBuf(8,9,10,11) = Number Of Interrupts

    'UPGRADE_NOTE: Str was upgraded to Str_Renamed. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
    Public Function ConvertToVBString(ByRef Str_Renamed As Byte()) As String

        Dim NewString As String = ""
        Dim i As Short

        'for the received string array, loop until we get
        'a 0 char, or until the max length has been obtained
        'then add the ascii char value to a vb string
        i = 0
        Do While (i < SI_MAX_DEVICE_STRLEN) And (Str_Renamed(i) <> 0)
            NewString = NewString & Chr(Str_Renamed(i))
            i = i + 1
        Loop

        ConvertToVBString = NewString

    End Function

    Public Sub WriteFileData()

        Dim Success As Boolean
        Success = True

        Dim FileNum As Short
        FileNum = FreeFile()

        'check if there is a valid file
        Dim FileSize As Long
        Dim BytesWritten As Integer
        Dim TotalWritten As Long
        Dim BytesRead As Integer
        Dim Buf(MAX_PACKET_SIZE_WRITE) As Byte
        Dim NumPkts As Integer
        Dim NumLoops As Integer
        Dim CounterPkts As Integer
        Dim CounterLoops As Integer
        Dim WriteLength As Integer
        Dim i As Short
        If frmMain.txtTransfer.Text <> "" Then
            FileOpen(FileNum, frmMain.txtTransfer.Text, OpenMode.Binary)

            FileSize = FileLen(frmMain.txtTransfer.Text)

            If FileSize > 4096 Then
                MsgBox("File Size Limit is 4096 Bytes")
                FileClose(FileNum)

            Else

                'if the file is valid, and exists then obtain its size,
                'and prepare to write data to the board
                If FileSize > 0 Then

                    BytesWritten = 0
                    BytesRead = 0

                    Buf(0) = FT_WRITE_MSG
                    Buf(1) = FileSize And &HFFS
                    Buf(2) = CShort(FileSize And &HFF00S) / 256

                    'send the board a write message
                    If (DeviceWrite(Buf, FT_MSG_SIZE, BytesWritten)) Then
                        If BytesWritten = FT_MSG_SIZE Then

                            'send data to the board in groups of 8 packets
                            If (FileSize Mod MAX_PACKET_SIZE_WRITE) > 0 Then
                                NumPkts = (FileSize \ MAX_PACKET_SIZE_WRITE) + 1
                            Else
                                NumPkts = (FileSize \ MAX_PACKET_SIZE_WRITE)
                            End If
                            If (NumPkts Mod MAX_WRITE_PKTS) > 0 Then
                                NumLoops = (NumPkts \ MAX_WRITE_PKTS) + 1
                            Else
                                NumLoops = (NumPkts \ MAX_WRITE_PKTS)
                            End If
                            CounterPkts = 0
                            CounterLoops = 0
                            TotalWritten = 0

                            WriteLength = 0
                            Do While (CounterLoops < NumLoops) And Success
                                i = 0
                                Do While (i < MAX_WRITE_PKTS) And (CounterPkts < NumPkts) And Success

                                    If ((FileSize - TotalWritten) < MAX_PACKET_SIZE_WRITE) Then
                                        WriteLength = FileSize - TotalWritten
                                    Else
                                        WriteLength = MAX_PACKET_SIZE_WRITE
                                    End If

                                    'for each section of 8 packets, clear the buffer
                                    'then load the next section of data to send
                                    Call MemSet(Buf, 0, WriteLength)
                                    Call FileRead(FileNum, Buf, WriteLength)
                                    BytesWritten = 0

                                    Success = DeviceWrite(Buf, WriteLength, BytesWritten)
                                    TotalWritten = TotalWritten + BytesWritten
                                    CounterPkts = CounterPkts + 1
                                    i = i + 1
                                Loop

                                If Success Then
                                    Call MemSet(Buf, 0, MAX_PACKET_SIZE_WRITE)

                                    'check for ack packet after writing 8 packets
                                    Do While (Buf(0) <> 255) And Success
                                        Success = DeviceRead(Buf, 1, BytesRead)
                                    Loop
                                End If

                                CounterLoops = CounterLoops + 1
                            Loop
                        Else
                            MsgBox("Incomplete Write File Size Message Sent to Device")
                            Success = False
                        End If
                    Else
                        MsgBox("Target Device Failure While Sending File Size Information")
                        Success = False
                    End If

                    FileClose(FileNum)
                Else
                    MsgBox("Failed to Open File " & frmMain.txtTransfer.Text)
                    Success = False
                End If

            End If

        Else
            MsgBox("No File Selected")
            Success = False
        End If

    End Sub

    Public Function DeviceWrite(ByRef Buffer() As Byte, ByRef dwSize As Integer, ByRef lpdwBytesWritten As Integer) As Boolean
        Dim WriteStatus As Short

        WriteStatus = SI_Write(hUSBDevice, Buffer(0), dwSize, lpdwBytesWritten, 0)

        If WriteStatus = SI_SUCCESS Then
            DeviceWrite = True
        Else
            DeviceWrite = False
        End If

    End Function

    Public Sub ReadFileData()

        Dim Success As Boolean
        Success = True

        Dim FileNum As Short
        FileNum = FreeFile()

        TempString = ""

        'check if there is a valid file
        Dim BytesRead As Integer
        Dim BytesWritten As Integer
        Dim Buf(MAX_PACKET_SIZE_READ) As Byte
        Dim FileSize As Integer
        Dim CounterPkts As Integer
        Dim NumPkts As Integer
        If frmMain.txtReceive.Text <> "" Then
            FileOpen(FileNum, frmMain.txtReceive.Text, OpenMode.Output)


            Buf(0) = FT_READ_MSG
            Buf(1) = &HFFS
            Buf(2) = &HFFS

            'send the board a read message
            If (DeviceWrite(Buf, FT_MSG_SIZE, BytesWritten)) Then

                FileSize = 0
                CounterPkts = 0
                NumPkts = 0
                Call MemSet(Buf, 0, MAX_PACKET_SIZE_READ)

                'determine the file size and number of packets to
                'receive from the board
                If (DeviceRead(Buf, FT_MSG_SIZE, BytesRead)) Then
                    FileSize = ((Buf(1) And &HFFS) Or ((Buf(2) * 256) And &HFF00S))
                    If (FileSize Mod MAX_PACKET_SIZE_READ) > 0 Then
                        NumPkts = (FileSize \ MAX_PACKET_SIZE_READ) + 1
                    Else
                        NumPkts = (FileSize \ MAX_PACKET_SIZE_READ)
                    End If

                    'send each packet back to the board and store it in a temp
                    'string via the FileWrite function
                    Do While (CounterPkts < NumPkts) And Success
                        Call MemSet(Buf, 0, MAX_PACKET_SIZE_READ)
                        BytesRead = 0

                        If (DeviceRead(Buf, MAX_PACKET_SIZE_READ, BytesRead)) Then
                            If (CounterPkts < (NumPkts - 1)) Then
                                Call FileWrite(FileNum, Buf, MAX_PACKET_SIZE_READ)
                            Else
                                'check to see if last packet is partial
                                If (FileSize Mod MAX_PACKET_SIZE_READ) > 0 Then
                                    Call FileWrite(FileNum, Buf, (FileSize Mod MAX_PACKET_SIZE_READ))
                                Else
                                    Call FileWrite(FileNum, Buf, MAX_PACKET_SIZE_READ)
                                End If
                            End If
                        Else
                            MsgBox("Failed Reading File Packet From Target Device")
                        End If

                        CounterPkts = CounterPkts + 1
                    Loop
                Else
                    MsgBox("Target Device Failure While Sending Read File Message")
                End If
            Else
                MsgBox("Target Device Failure While Sending File Size Information")
                Success = False
            End If

            'write the entire temporary string to the output file chosen
            Print(FileNum, TempString)

            FileClose(FileNum)
        Else
            MsgBox("No File Selected")
            Success = False
        End If

    End Sub

    Public Function DeviceRead(ByRef Buffer() As Byte, ByRef dwSize As Integer, ByRef lpdwBytesRead As Integer) As Boolean

        Dim ReadStatus As Short
        Dim BytesInQueue As Integer
        BytesInQueue = 0

        ReadStatus = SI_Read(hUSBDevice, Buffer(0), dwSize, lpdwBytesRead, 0)

        If ReadStatus = SI_SUCCESS Then
            DeviceRead = True
        Else
            DeviceRead = False
        End If

    End Function

    Public Sub MemSet(ByRef Buffer() As Byte, ByRef Value As Byte, ByRef Amount As Integer)

        'this function sets all elements of on array to 0
        Dim i As Integer

        For i = 0 To (Amount - 1)
            Buffer(i) = Value
        Next

    End Sub

    Public Sub FileRead(ByRef FileNum As Short, ByRef Buffer() As Byte, ByRef NumberOfBytes As Integer)

        'this function converts the characters of a text file to bytes of
        'binary data to send out
        Dim i As Integer
        Dim Tmp As String

        For i = 0 To NumberOfBytes - 1
            If (Not EOF(FileNum)) Then
                Tmp = InputString(1, FileNum)
                If Tmp <> "" Then
                    Buffer(i) = Asc(Tmp)
                Else
                    Buffer(i) = 0
                End If
            End If
        Next

    End Sub

    Public Sub FileWrite(ByRef FileNum As Short, ByRef Buffer() As Byte, ByRef NumberOfBytes As Integer)

        'this function puts all the characters from the buffer in a temp
        'string to be dumped into a file after everything has been read
        Dim i As Integer

        For i = 0 To NumberOfBytes - 1
            TempString = TempString + Chr(Buffer(i))
        Next

    End Sub
End Module