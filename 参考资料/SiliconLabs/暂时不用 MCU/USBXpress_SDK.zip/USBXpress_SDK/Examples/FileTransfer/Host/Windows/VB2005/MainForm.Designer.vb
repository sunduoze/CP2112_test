<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmMain
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public CommonDialog1Open As System.Windows.Forms.OpenFileDialog
	Public WithEvents cmdBrowseReceive As System.Windows.Forms.Button
	Public WithEvents cmdBrowseTransfer As System.Windows.Forms.Button
	Public WithEvents cmdReceive As System.Windows.Forms.Button
	Public WithEvents cmdTransfer As System.Windows.Forms.Button
	Public WithEvents txtReceive As System.Windows.Forms.TextBox
	Public WithEvents txtTransfer As System.Windows.Forms.TextBox
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents cmdUpdateDeviceList As System.Windows.Forms.Button
	Public WithEvents cmbDevice As System.Windows.Forms.ComboBox
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.CommonDialog1Open = New System.Windows.Forms.OpenFileDialog
		Me.cmdBrowseReceive = New System.Windows.Forms.Button
		Me.cmdBrowseTransfer = New System.Windows.Forms.Button
		Me.cmdReceive = New System.Windows.Forms.Button
		Me.cmdTransfer = New System.Windows.Forms.Button
		Me.txtReceive = New System.Windows.Forms.TextBox
		Me.txtTransfer = New System.Windows.Forms.TextBox
		Me.cmdClose = New System.Windows.Forms.Button
		Me.cmdUpdateDeviceList = New System.Windows.Forms.Button
		Me.cmbDevice = New System.Windows.Forms.ComboBox
		Me.Label3 = New System.Windows.Forms.Label
		Me.Label2 = New System.Windows.Forms.Label
		Me.Label1 = New System.Windows.Forms.Label
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		Me.Text = "USB File Transfer"
		Me.ClientSize = New System.Drawing.Size(544, 217)
		Me.Location = New System.Drawing.Point(4, 23)
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
		Me.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmMain"
		Me.cmdBrowseReceive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdBrowseReceive.Text = "Browse"
		Me.cmdBrowseReceive.Size = New System.Drawing.Size(81, 25)
		Me.cmdBrowseReceive.Location = New System.Drawing.Point(440, 168)
		Me.cmdBrowseReceive.TabIndex = 11
		Me.cmdBrowseReceive.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdBrowseReceive.BackColor = System.Drawing.SystemColors.Control
		Me.cmdBrowseReceive.CausesValidation = True
		Me.cmdBrowseReceive.Enabled = True
		Me.cmdBrowseReceive.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdBrowseReceive.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdBrowseReceive.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdBrowseReceive.TabStop = True
		Me.cmdBrowseReceive.Name = "cmdBrowseReceive"
		Me.cmdBrowseTransfer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdBrowseTransfer.Text = "Browse"
		Me.cmdBrowseTransfer.Size = New System.Drawing.Size(81, 25)
		Me.cmdBrowseTransfer.Location = New System.Drawing.Point(440, 112)
		Me.cmdBrowseTransfer.TabIndex = 10
		Me.cmdBrowseTransfer.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdBrowseTransfer.BackColor = System.Drawing.SystemColors.Control
		Me.cmdBrowseTransfer.CausesValidation = True
		Me.cmdBrowseTransfer.Enabled = True
		Me.cmdBrowseTransfer.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdBrowseTransfer.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdBrowseTransfer.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdBrowseTransfer.TabStop = True
		Me.cmdBrowseTransfer.Name = "cmdBrowseTransfer"
		Me.cmdReceive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdReceive.Text = "Receive Data"
		Me.cmdReceive.Size = New System.Drawing.Size(89, 25)
		Me.cmdReceive.Location = New System.Drawing.Point(24, 168)
		Me.cmdReceive.TabIndex = 7
		Me.cmdReceive.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdReceive.BackColor = System.Drawing.SystemColors.Control
		Me.cmdReceive.CausesValidation = True
		Me.cmdReceive.Enabled = True
		Me.cmdReceive.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdReceive.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdReceive.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdReceive.TabStop = True
		Me.cmdReceive.Name = "cmdReceive"
		Me.cmdTransfer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdTransfer.Text = "Transfer Data"
		Me.cmdTransfer.Size = New System.Drawing.Size(89, 25)
		Me.cmdTransfer.Location = New System.Drawing.Point(24, 112)
		Me.cmdTransfer.TabIndex = 6
		Me.cmdTransfer.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdTransfer.BackColor = System.Drawing.SystemColors.Control
		Me.cmdTransfer.CausesValidation = True
		Me.cmdTransfer.Enabled = True
		Me.cmdTransfer.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdTransfer.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdTransfer.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdTransfer.TabStop = True
		Me.cmdTransfer.Name = "cmdTransfer"
		Me.txtReceive.AutoSize = False
		Me.txtReceive.Size = New System.Drawing.Size(305, 19)
		Me.txtReceive.Location = New System.Drawing.Point(128, 168)
		Me.txtReceive.TabIndex = 5
		Me.txtReceive.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtReceive.AcceptsReturn = True
		Me.txtReceive.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtReceive.BackColor = System.Drawing.SystemColors.Window
		Me.txtReceive.CausesValidation = True
		Me.txtReceive.Enabled = True
		Me.txtReceive.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtReceive.HideSelection = True
		Me.txtReceive.ReadOnly = False
		Me.txtReceive.Maxlength = 0
		Me.txtReceive.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtReceive.MultiLine = False
		Me.txtReceive.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtReceive.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtReceive.TabStop = True
		Me.txtReceive.Visible = True
		Me.txtReceive.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtReceive.Name = "txtReceive"
		Me.txtTransfer.AutoSize = False
		Me.txtTransfer.Size = New System.Drawing.Size(305, 19)
		Me.txtTransfer.Location = New System.Drawing.Point(128, 112)
		Me.txtTransfer.TabIndex = 4
		Me.txtTransfer.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtTransfer.AcceptsReturn = True
		Me.txtTransfer.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtTransfer.BackColor = System.Drawing.SystemColors.Window
		Me.txtTransfer.CausesValidation = True
		Me.txtTransfer.Enabled = True
		Me.txtTransfer.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtTransfer.HideSelection = True
		Me.txtTransfer.ReadOnly = False
		Me.txtTransfer.Maxlength = 0
		Me.txtTransfer.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtTransfer.MultiLine = False
		Me.txtTransfer.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtTransfer.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtTransfer.TabStop = True
		Me.txtTransfer.Visible = True
		Me.txtTransfer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtTransfer.Name = "txtTransfer"
		Me.cmdClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdClose.Text = "Close"
		Me.cmdClose.Size = New System.Drawing.Size(89, 25)
		Me.cmdClose.Location = New System.Drawing.Point(432, 16)
		Me.cmdClose.TabIndex = 3
		Me.cmdClose.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
		Me.cmdClose.CausesValidation = True
		Me.cmdClose.Enabled = True
		Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdClose.TabStop = True
		Me.cmdClose.Name = "cmdClose"
		Me.cmdUpdateDeviceList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdUpdateDeviceList.Text = "Update Device List"
		Me.cmdUpdateDeviceList.Size = New System.Drawing.Size(105, 25)
		Me.cmdUpdateDeviceList.Location = New System.Drawing.Point(216, 48)
		Me.cmdUpdateDeviceList.TabIndex = 2
		Me.cmdUpdateDeviceList.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdUpdateDeviceList.BackColor = System.Drawing.SystemColors.Control
		Me.cmdUpdateDeviceList.CausesValidation = True
		Me.cmdUpdateDeviceList.Enabled = True
		Me.cmdUpdateDeviceList.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdUpdateDeviceList.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdUpdateDeviceList.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdUpdateDeviceList.TabStop = True
		Me.cmdUpdateDeviceList.Name = "cmdUpdateDeviceList"
		Me.cmbDevice.Size = New System.Drawing.Size(153, 21)
		Me.cmbDevice.Location = New System.Drawing.Point(48, 48)
		Me.cmbDevice.TabIndex = 1
		Me.cmbDevice.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmbDevice.BackColor = System.Drawing.SystemColors.Window
		Me.cmbDevice.CausesValidation = True
		Me.cmbDevice.Enabled = True
		Me.cmbDevice.ForeColor = System.Drawing.SystemColors.WindowText
		Me.cmbDevice.IntegralHeight = True
		Me.cmbDevice.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmbDevice.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmbDevice.Sorted = False
		Me.cmbDevice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown
		Me.cmbDevice.TabStop = True
		Me.cmbDevice.Visible = True
		Me.cmbDevice.Name = "cmbDevice"
		Me.Label3.Text = "Receive File Name:"
		Me.Label3.Size = New System.Drawing.Size(153, 17)
		Me.Label3.Location = New System.Drawing.Point(128, 144)
		Me.Label3.TabIndex = 9
		Me.Label3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label3.BackColor = System.Drawing.SystemColors.Control
		Me.Label3.Enabled = True
		Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label3.UseMnemonic = True
		Me.Label3.Visible = True
		Me.Label3.AutoSize = False
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label3.Name = "Label3"
		Me.Label2.Text = "Transfer File Name:"
		Me.Label2.Size = New System.Drawing.Size(137, 17)
		Me.Label2.Location = New System.Drawing.Point(128, 88)
		Me.Label2.TabIndex = 8
		Me.Label2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label2.BackColor = System.Drawing.SystemColors.Control
		Me.Label2.Enabled = True
		Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label2.UseMnemonic = True
		Me.Label2.Visible = True
		Me.Label2.AutoSize = False
		Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label2.Name = "Label2"
		Me.Label1.Text = "Select Device:"
		Me.Label1.Size = New System.Drawing.Size(89, 17)
		Me.Label1.Location = New System.Drawing.Point(48, 24)
		Me.Label1.TabIndex = 0
		Me.Label1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label1.BackColor = System.Drawing.SystemColors.Control
		Me.Label1.Enabled = True
		Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label1.UseMnemonic = True
		Me.Label1.Visible = True
		Me.Label1.AutoSize = False
		Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label1.Name = "Label1"
		Me.Controls.Add(cmdBrowseReceive)
		Me.Controls.Add(cmdBrowseTransfer)
		Me.Controls.Add(cmdReceive)
		Me.Controls.Add(cmdTransfer)
		Me.Controls.Add(txtReceive)
		Me.Controls.Add(txtTransfer)
		Me.Controls.Add(cmdClose)
		Me.Controls.Add(cmdUpdateDeviceList)
		Me.Controls.Add(cmbDevice)
		Me.Controls.Add(Label3)
		Me.Controls.Add(Label2)
		Me.Controls.Add(Label1)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class