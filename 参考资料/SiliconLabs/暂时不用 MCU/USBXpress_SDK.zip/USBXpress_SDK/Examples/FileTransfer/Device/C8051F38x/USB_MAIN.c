//-----------------------------------------------------------------------------
// USB_MAIN.c
//-----------------------------------------------------------------------------
// Copyright 2011 Silicon Laboratories, Inc.
//
// Target: C8051F38x
// Tool chain: KEIL / SDCC / Raisonance
//
// REVISIONS:
// Author ES    DATE  1-12-11
// Modified ES DATE  1-12-11
//  -Initial Release
//
// This example illustrates usage of the USB_API.lib
// DO NOT locate code segments at 0x1400 to 0x4000
// These are used for non-voltile storage for transmitted data.
//
//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
#include "compiler_defs.h"
#include "c8051f380_defs.h"   // Header file for SiLabs C8051f340
#include <stddef.h>           // Used for NULL pointer definition
#include "USB_API.h"          // Header file for USB_API.lib

#define  INTERRUPT_USBXpress     17

//-----------------------------------------------------------------------------
// Global CONSTANTS
//-----------------------------------------------------------------------------

SBIT(Led1, SFR_P2, 2);         // LED='1' means ON
SBIT(Led2, SFR_P2, 3);         // These blink to indicate data transmission

// Constants Definitions
#define  NUM_STG_PAGES  20 // Total number of flash pages to be used for file storage
#define  MAX_BLOCK_SIZE_READ     64 // Use the maximum read block size of 64 bytes

#define  MAX_BLOCK_SIZE_WRITE    4096   // Use the maximum write block size of 4096 bytes
#define  FLASH_PAGE_SIZE         512    //  Size of each flash page
#define  BLOCKS_PR_PAGE  FLASH_PAGE_SIZE/MAX_BLOCK_SIZE_READ  // 512/64 = 8
#define  MAX_NUM_BYTES   FLASH_PAGE_SIZE*NUM_STG_PAGES
#define  MAX_NUM_BLOCKS  BLOCKS_PR_PAGE*NUM_STG_PAGES

// Message Types
#define  READ_MSG          0x00  // Message types for communication with host
#define  WRITE_MSG         0x01
#define  SIZE_MSG          0x02
#define  DELAYED_READ_MSG  0x05

// Machine States
#define  ST_WAIT_DEV    0x01  // Wait for application to open a device instance
#define  ST_IDLE_DEV    0x02  // Device is open, wait for Setup Message from host
#define  ST_RX_SETUP    0x04  // Received Setup Message, decode and wait for data
#define  ST_RX_FILE     0x08  // Receive file data from host
#define  ST_TX_FILE     0x10  // Transmit file data to host
#define  ST_TX_ACK      0x20  // Transmit ACK 0xFF back to host after every 8 packets
#define  ST_ERROR       0x80  // Error state

// No such thing as a block of data anymore since it is variable between 1 and 1024
// So comment this out
typedef struct {        // Structure definition of a block of data
   U8  Piece[MAX_BLOCK_SIZE_READ];
}  BLOCK;

typedef struct {        // Structure definition of a flash memory page
   U8  FlashPage[FLASH_PAGE_SIZE];
}  PAGE;


SEGMENT_VARIABLE(TempStorage[BLOCKS_PR_PAGE], BLOCK, SEG_XDATA); //Temporary storage of between flash writes

SEGMENT_VARIABLE_SEGMENT_POINTER(PageIndices[20], U8, SEG_CODE, SEG_DATA);

SEGMENT_VARIABLE(BytesToRead, U16, SEG_DATA); // Total number of bytes to read from host
SEGMENT_VARIABLE(WriteStageLength, U16, SEG_DATA); //  Current write transfer stage length
SEGMENT_VARIABLE(ReadStageLength, U16, SEG_DATA);  //  Current read transfer stage length
SEGMENT_VARIABLE(Buffer[3], U8, SEG_DATA);   // Buffer for Setup messages
SEGMENT_VARIABLE(NumBytes, U16, SEG_DATA);   // Number of Blocks for this transfer
SEGMENT_VARIABLE(NumBlocks, U8, SEG_DATA);
SEGMENT_VARIABLE(BytesRead, U16, SEG_DATA);  // Number of Bytes Read
SEGMENT_VARIABLE(M_State, U8, SEG_DATA);     // Current Machine State
SEGMENT_VARIABLE(BytesWrote, U16, SEG_DATA); // Number of Bytes Written
SEGMENT_VARIABLE(BlockIndex, U8, SEG_DATA);  // Index of Current Block in Page
SEGMENT_VARIABLE(PageIndex, U8, SEG_DATA);   // Index of Current Page in File
SEGMENT_VARIABLE(BlocksWrote, U8, SEG_DATA); // Total Number of Blocks Written
#if defined __C51__
   SEGMENT_VARIABLE(ReadIndex, U8*, SEG_DATA);
#elif defined SDCC
   SEGMENT_VARIABLE_SEGMENT_POINTER(ReadIndex, U8, SEG_CODE, SEG_DATA);
#endif
SEGMENT_VARIABLE(BytesToWrite, U16, SEG_DATA);

/*** [BEGIN] USB Descriptor Information [BEGIN] ***/
SEGMENT_VARIABLE(USB_VID, U16, SEG_CODE) = 0x10C4;
SEGMENT_VARIABLE(USB_PID, U16, SEG_CODE) = 0xEA61;
SEGMENT_VARIABLE(USB_MfrStr[], U8, SEG_CODE) = // Manufacturer String
{
   0x1A,
   0x03,
   'S',0,
   'i',0,
   'l',0,
   'i',0,
   'c',0,
   'o',0,
   'n',0,
   ' ',0,
   'L',0,
   'a',0,
   'b',0,
   's',0
};
SEGMENT_VARIABLE(USB_ProductStr[], U8, SEG_CODE) = // Product Desc. String
{
   0x10,
   0x03,
   'U',0,
   'S',0,
   'B',0,
   ' ',0,
   'A',0,
   'P',0,
   'I',0
};
SEGMENT_VARIABLE(USB_SerialStr[], U8, SEG_CODE) = // Serial Number String
{
   0x0A,
   0x03,
   '1',0,
   '2',0,
   '3',0,
   '4',0
};
SEGMENT_VARIABLE(USB_MaxPower, U8, SEG_CODE) = 15; // Max current = 30 mA
                                                   // (15 * 2)
SEGMENT_VARIABLE(USB_PwAttributes, U8, SEG_CODE) = 0x80;    // Bus-powered,
                                                            // remote wakeup not
                                                            // supported
SEGMENT_VARIABLE(USB_bcdDevice, U16, SEG_CODE) = 0x0100;    // Device release
                                                            // number 1.00
/*** [ END ] USB Descriptor Information [ END ] ***/

LOCATED_VARIABLE_NO_INIT(LengthFile[3], U8, SEG_CODE, 0x2000);
   // {Length(Low Byte), Length(High Byte), Number of Blocks}

//-----------------------------------------------------------------------------
// Function Prototypes
//-----------------------------------------------------------------------------

void  Port_Init(void);        // Initialize Ports Pins and Enable Crossbar
void  State_Machine(void);    // Determine new state and act on current state
void  Receive_Setup(void);    // Receive and decode setup packet from host
void  Receive_File(void);     // Receive file data from host
//void   Suspend_Device(void);      //  Place the device in suspend mode
void  Page_Erase(U8*);      // Erase a flash page
void  Page_Write(U8*);      // Write a flash page

//-----------------------------------------------------------------------------
// Main Routine
//-----------------------------------------------------------------------------
void main(void)
{

   U8 j;                         // temporary counter
   PCA0MD &= ~0x40;              // Disable Watchdog timer

   // Initialize pointer to flash pages where data will be stored
   PageIndices[0]  = 0x2200;
   for (j=1; j<20; j++)
   {
      PageIndices[j] = PageIndices[j-1] + 0x200;
   }

   USB_Clock_Start();            // Init USB clock *before* calling USB_Init
   USB_Init(USB_VID,USB_PID,USB_MfrStr,USB_ProductStr,USB_SerialStr,USB_MaxPower,USB_PwAttributes,USB_bcdDevice);

   CLKSEL |= 0x02;


   RSTSRC   |= 0x02;

   Port_Init();                  // Initialize crossbar and GPIO

   USB_Int_Enable();             // Enable USB_API Interrupts
      while (1);
}

void  Port_Init(void)
{
   P2MDOUT  |= 0x0C;             // Port 2 pins 0,1 set high impedence
   XBR0  =  0x00;
   XBR1  =  0x40;                // Enable Crossbar
}

void  Page_Erase (U8*  Page_Address)
{
   U8  EA_Save;               // Used to save state of global interrupt enable
   U8  SEG_XDATA *pwrite;     // xdata pointer used to generate movx intruction

   EA_Save  =  EA;            // Save current EA
   EA =  0;                   // Turn off interrupts
   pwrite   =  (U8 SEG_XDATA *)(Page_Address); // Set write pointer to Page_Address
   PSCTL =  0x03;             // Enable flash erase and writes

   FLKEY =  0xA5;             // Write flash key sequence to FLKEY
   FLKEY =  0xF1;
   *pwrite  =  0x00;          // Erase flash page using a write command

   PSCTL =  0x00;             // Disable flash erase and writes
   EA =  EA_Save;             // Restore state of EA
}

void  Page_Write (U8*  PageAddress)
{
   U8  EA_Save;             // Used to save state of global interrupt enable
   U8  SEG_XDATA *pwrite;   // Write Pointer
   U8  SEG_XDATA *pread;    // Read Pointer
   U16  x;                  // Counter for 0-512 bytes

   pread =  (U8 SEG_XDATA *)(TempStorage);
   EA_Save  =  EA;            // Save EA
   EA =  0;                   // Turn off interrupts
   pwrite   =  (U8 SEG_XDATA *)(PageAddress);
   PSCTL =  0x01;             // Enable flash writes
   for(x = 0;  x<FLASH_PAGE_SIZE;   x++) // Write 512 bytes
   {
      FLKEY =  0xA5;          // Write flash key sequence
      FLKEY =  0xF1;
      *pwrite  =  *pread;     // Write data byte to flash

      pread++;                // Increment pointers
      pwrite++;
   }
   PSCTL =  0x00;             // Disable flash writes
   EA =  EA_Save;             // Restore EA
}

void  State_Machine(void)
{
   switch   (M_State)
   {
      case  ST_RX_SETUP:
         Receive_Setup();           // Receive and decode host Setup Message
         break;
      case  ST_RX_FILE:
         Receive_File();            // Receive File data from host
         break;
      case  ST_TX_ACK:
         M_State =   ST_RX_FILE;    // Ack Transmit complete, continue RX data
         break;
      case  ST_TX_FILE:             // Send file data to host
         WriteStageLength = ((BytesToWrite - BytesWrote) > MAX_BLOCK_SIZE_WRITE)? MAX_BLOCK_SIZE_WRITE:(BytesToWrite - BytesWrote);
         BytesWrote  += Block_Write((U8*)(ReadIndex), WriteStageLength);
         ReadIndex += WriteStageLength;

         if ((BlocksWrote%8) == 0)  Led2 = !Led2;
         if (BytesWrote == NumBytes)   Led2 = 0;
         break;
      default:
         break;
   }
}


   // ISR for USB_API, run when API interrupts are enabled, and an interrupt is received
INTERRUPT(USB_API_TEST_ISR, INTERRUPT_USBXpress)
{
   U8  INTVAL   =  Get_Interrupt_Source();  // Determine type of API interrupts
   if (INTVAL  &  USB_RESET)                // Bus Reset Event, go to Wait State
   {
      M_State  =  ST_WAIT_DEV;
   }

   if (INTVAL  &  DEVICE_OPEN)            // Device opened on host, go to Idle
   {
      M_State  =  ST_IDLE_DEV;
   }

   if (INTVAL  &  TX_COMPLETE)
   {
      if (M_State == ST_RX_FILE)          // Ack Transmit complete, go to RX state
      {
         M_State  =  (ST_TX_ACK);
      }
      if (M_State == ST_TX_FILE)          // File block transmit complete, go to TX state
      {
         M_State  =  (BytesWrote == BytesToWrite) ? ST_IDLE_DEV :ST_TX_FILE;  // Go to Idle when done
      }
   }
   if (INTVAL  &  RX_COMPLETE)            // RX Complete, go to RX Setup or RX file state
   {
      M_State  =  (M_State == ST_IDLE_DEV) ? ST_RX_SETUP : ST_RX_FILE;
   }
   if (INTVAL  &  DEVICE_CLOSE)           // Device closed, wait for re-open
   {
      M_State  =  ST_WAIT_DEV;
   }
   if (INTVAL  &  FIFO_PURGE)             // Fifo purged, go to Idle State
   {
      M_State  =  ST_IDLE_DEV;
   }

   State_Machine();                       // Call state machine routine
}

void  Receive_Setup (void)
{
   #if defined SDCC
      SEGMENT_VARIABLE_SEGMENT_POINTER(temp_address, U8, SEG_DATA, SEG_DATA) = 0x2000;
   #endif

   #if defined __C51__
      BytesRead   =  Block_Read(&Buffer,  3);      // Read Setup Message
   #elif defined SDCC
      BytesRead   =  Block_Read(Buffer,  3);       // Read Setup Message
   #endif

   if (Buffer[0]  == READ_MSG)         // Check See if Read File Setup
   {
      PageIndex   =  0;                // Reset Index
      NumBlocks   =  LengthFile[2];    // Read NumBlocks from flash stg
      NumBlocks   = (NumBlocks > MAX_NUM_BLOCKS)?  MAX_NUM_BLOCKS:   NumBlocks;
                                          // only write as many bytes
                                          // as we have space available
      Buffer[0]   =  SIZE_MSG;            // Send host size of transfer message
      Buffer[1]   =  LengthFile[1];
      Buffer[2]   =  LengthFile[0];
      BytesToWrite   =  Buffer[1]   +  256*Buffer[2];
      BytesWrote  =  Block_Write((U8*)&Buffer,   3);
      M_State  =  ST_TX_FILE;             // Go to TX data state
      BytesWrote  =  0;

      ReadIndex   =  PageIndices[0];

      Led2  =  1;
   }
   else  // Otherwise assume Write Setup Packet
   {
      BytesToRead =  Buffer[1]   +  256*Buffer[2];
      NumBlocks   =  (U8)(BytesToRead/MAX_BLOCK_SIZE_READ);  // Find NumBlocks

      if (BytesToRead > MAX_NUM_BYTES)                // State Error if transfer too big
      {
         M_State = ST_ERROR;
      }
      else
      {

         if (BytesToRead%MAX_BLOCK_SIZE_READ)   NumBlocks++;   // Increment NumBlocks for last partial block

         TempStorage->Piece[0]   =  Buffer[2];
         TempStorage->Piece[1]   =  Buffer[1];
         TempStorage->Piece[2]   =  NumBlocks;

         // Write Values to Flash
         #if defined (__RC51__) || defined (__C51__)
            Page_Erase(0x2000);                       // Store file data to flash
            Page_Write(0x2000);
         #elif defined SDCC
            Page_Erase(temp_address);                 // Store file data to flash
            Page_Write(temp_address);
         #endif

         PageIndex   =  0;                         // Reset Index
         BlockIndex  =  0;
         BytesRead   =  0;
         Led1  =  1;
         M_State = ST_RX_FILE;                     // Go to RX data state
      }
   }
}

void  Receive_File(void)
{
   ReadStageLength = ((BytesToRead - BytesRead) > MAX_BLOCK_SIZE_READ)? MAX_BLOCK_SIZE_READ:(BytesToRead - BytesRead);

   BytesRead   += Block_Read((U8*)(&TempStorage[BlockIndex]), ReadStageLength);   // Read Block

   BlockIndex++;
   // If device has received as many bytes as fit on one FLASH page, disable interrupts,
   // write page to flash, reset packet index, enable interrupts
   // Send handshake packet 0xFF to host after FLASH write
   if ((BlockIndex   == (BLOCKS_PR_PAGE)) || (BytesRead  == BytesToRead))
   {
      Page_Erase((U8*)(PageIndices[PageIndex]));
      Page_Write((U8*)(PageIndices[PageIndex]));
      PageIndex++;
      Led1 = !Led1;
      BlockIndex  =  0;
      Buffer[0]   =  0xFF;
      Block_Write(Buffer,  1);         // Send handshake Acknowledge to host
   }

   // Go to Idle state if last packet has been received
   if (BytesRead  == BytesToRead)   {M_State =  ST_IDLE_DEV;   Led1  =  0;}
}

// Startup code for SDCC to disablt WDT before initializing variables so that
// a reset does not occur
#if defined SDCC
void _sdcc_external_startup (void)
{
   PCA0MD &= ~0x40;                    // Disable Watchdog timer
}
#endif

// ============================================================================
// *** END OF FILE ***
// ============================================================================
