// CP210x TestDlg.h : header file
//

#if !defined(AFX_CP210XTESTDLG_H__DB634428_201D_4E23_8C46_127454EDA1A7__INCLUDED_)
#define AFX_CP210XTESTDLG_H__DB634428_201D_4E23_8C46_127454EDA1A7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCP210xTestDlg dialog

class CCP210xTestDlg : public CDialog
{
// Construction
public:
	CCP210xTestDlg(CWnd* pParent = NULL);	// standard constructor
	void DelayMS(UINT delay);
// Dialog Data
	//{{AFX_DATA(CCP210xTestDlg)
	enum { IDD = IDD_CP210XTEST_DIALOG };
	UINT	m_port1;
	UINT	m_port2;
	CString	m_output;
	UINT	m_port_num;
	//}}AFX_DATA
		
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCP210xTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

	void FillDeviceList(void);

// Implementation
protected:
	HICON m_hIcon;

// Generated message map functions
	//{{AFX_MSG(CCP210xTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnExit();
	afx_msg void OnStart();
	afx_msg void OnUpdateDeviceList();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	bool Transfer(HANDLE* hDev1, HANDLE* hDev2);
	HANDLE m_hUSBDevice;
	
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CP210XTESTDLG_H__DB634428_201D_4E23_8C46_127454EDA1A7__INCLUDED_)
