// CP210x Test.h : main header file for the CP210X TEST application
//

#if !defined(AFX_CP210XTEST_H__959E9CA8_6795_41E7_A3F9_62868918098F__INCLUDED_)
#define AFX_CP210XTEST_H__959E9CA8_6795_41E7_A3F9_62868918098F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCP210xTestApp:
// See CP210x Test.cpp for the implementation of this class
//

class CCP210xTestApp : public CWinApp
{
public:
	CCP210xTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCP210xTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCP210xTestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CP210XTEST_H__959E9CA8_6795_41E7_A3F9_62868918098F__INCLUDED_)
