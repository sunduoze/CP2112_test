// CP210xWinCEtoWindowsHTTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "SIUSBXP_LIB.h"

//WriteData function to send data to the device
void WriteData(HANDLE hFile);

//Pointer to a file for output
FILE *testResults;

int _tmain(int argc, TCHAR *argv[], TCHAR *envp[])
{
	DWORD numDevices = 0;

	//Get the number of devices connected
	SI_GetNumDevices(&numDevices);

	//If there are devices connected, then open 
	//the first one and perform the test
	if (numDevices > 0)
	{
		_tprintf(_T("Running..."));

		HANDLE hDevice;

		//Open an output file for the results
		testResults = fopen("WinCEtoHTTestResults.txt", "w");
		
		//Open the first device, device 0
		if (SI_Open(0, &hDevice) == SI_SUCCESS)
		{
			//Call write data with the newly opened handle
			WriteData(hDevice);

			//Wait 500 ms for cleanup
			Sleep(500);

			//Close the device
			SI_Close(hDevice);
		}

		//Close the output files for the results
		fclose(testResults);
	}

	_tprintf(_T("\nDone \n"));

	return 1;
}

void WriteData(HANDLE hFile)
{
	DWORD dwBytesWritten = 0;
	DWORD checkRXBytes, queueStatus;
	BYTE output[26];

	//Fill the output buffer with letters
	for (BYTE i = 0; i < 26; i++)
		output[i] = i + 65;

	//Set the baud rate to 115200
	SI_SetBaudRate(hFile, 115200);

	//Call check recieve queue to get the bytes and status
	SI_CheckRXQueue(hFile, &checkRXBytes, &queueStatus);

	//Loop through and progressively send characters
	for(DWORD k = 1; k <= 26; k++)
	{
		_tprintf(_T("."));

		//Write k characters from the buffer
		if (SI_Write(hFile, &output, k, &dwBytesWritten) == SI_SUCCESS)
		{
			//Determine if the write succeeds
			if (dwBytesWritten == k)
				_ftprintf(testResults,  _T("Write Succeeded %d Bytes\n"), k);
			else
				_ftprintf(testResults,  _T("Write Failed %d Bytes, only wrote %d\n"), k, dwBytesWritten);
		}
		
		//Reset bytes written back to 0
		dwBytesWritten = 0;
	}
}
