// CP210xWinCETest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "SIUSBXP_LIB.h"

#define TIME_OUT 5000

//Test Functions
void TryKnownBaudRates(HANDLE cyHandle);
void ReadWrite(HANDLE hFile);

//File for test results
FILE *testResults;

//Baud Rate list
unsigned int BaudRates[29] = {	300, 600, 1200,
								1800, 2400, 4000,
								4800, 7200, 9600,
								14400, 16000, 19200,
								28800, 38400, 51200,
								56000, 57600, 64000,
								76800, 115200, 128000,
								153600, 230400, 250000,
								256000, 460800, 500000,
								576000, 921600 };


int main(int argc, TCHAR *argv[], TCHAR *envp[])
{
	DWORD numDevices = 0;
	BYTE latch = 0xBB;
	PORT_CONFIG	portConfig;
	SI_DEVICE_STRING devString;

	//Get the number of devices connected
	SI_GetNumDevices(&numDevices);

	//If there are devices connected, then open 
	//the first one and perform the test
	if (numDevices > 0)
	{
		_tprintf(_T("Running...\n\n"));

		HANDLE hDevice;

		//Open an output file for the results
		testResults = fopen("USBXpressTestOut.txt", "w");
		
		for (DWORD i = 0; i < numDevices; i++)
		{
			_ftprintf(testResults,  _T("Device %d Strings: \n"), i);
			SI_GetProductString(i, devString, SI_RETURN_SERIAL_NUMBER);
			_ftprintf(testResults,  _T("Serial Number: %s\n"), devString);
			SI_GetProductString(i, devString, SI_RETURN_DESCRIPTION);
			_ftprintf(testResults,  _T("Descriptions: %s\n"), devString);
			SI_GetProductString(i, devString, SI_RETURN_VID);
			_ftprintf(testResults,  _T("VID: %s\n"), devString);
			SI_GetProductString(i, devString, SI_RETURN_PID);
			_ftprintf(testResults,  _T("PID: %s\n\n"), devString);
		}

		//Open the first device, device 0
		if (SI_Open(0, &hDevice) == SI_SUCCESS)
		{
			SI_GetNumDevices(&numDevices);

			//Perform the Read/Write Tests
			ReadWrite(hDevice);

			//Try setting all the known baud rates
			TryKnownBaudRates(hDevice);

			//Try the Port Functions
			SI_ReadLatch(hDevice, &latch);
			SI_WriteLatch(hDevice, 0x0F, 0x0C);
			SI_ReadLatch(hDevice, &latch);
			SI_GetPortConfig(hDevice, &portConfig);
			SI_SetPortConfig(hDevice, &portConfig);

			//Close the Device
			SI_Close(hDevice);
		}

		//Close the file opened for the output results
		fclose( testResults );
	}

	_tprintf(_T("\nDone \n "));

	return 1;
}

void ReadWrite(HANDLE hFile)
{
	DWORD dwBytesWritten = 0;
	DWORD dwBytesRead = 0;
	DWORD timeOut = 0;
	DWORD checkRXBytes, queueStatus;
	UCHAR output[8192];
	UCHAR input[8192];

	//Fill the output buffer with some pattern data
	for (int i = 1; i <= 8192; i++)
		output[i] = i;

	//Fill the input buffer with all 0's
	for (int j = 1; j <= 8192; j++)
		input[i] = 0;

	//Set a standard working baud rate
	SI_SetBaudRate(hFile, 921600);

	//Do an initial check on the recieve queue
	SI_CheckRXQueue(hFile, &checkRXBytes, &queueStatus);

	//Loop through 128 times and increase the write amount
	//by 64 each time to get to the max 8192 block
	for (int k = 0; k <= 128; k++)
	{
		_tprintf(_T("."));

		//Write k * 64 to get a piece of the buffer to write
		SI_Write(hFile, &output, k*64, &dwBytesWritten);

		//Determine how many bytes were written and output the status
		if (dwBytesWritten == 0)
			_ftprintf(testResults,  _T("Write Failed %d Bytes\n"), k*64);
		else
			_ftprintf(testResults,  _T("Write Succeeded %d Bytes\n"), k*64);

		//Reset timeout and recieve queue bytes
		timeOut = 0;
		checkRXBytes = 0;

		//Keep checking the recieve queue until timeout occurs, or
		//the number of bytes just written is in the queue
		while ((checkRXBytes != dwBytesWritten) && (timeOut != TIME_OUT))
		{
			SI_CheckRXQueue(hFile, &checkRXBytes, &queueStatus);
			timeOut++;
		}

		//Perform the read on k * 64 chunk of data we just wrote
		SI_Read(hFile, &input, k*64, &dwBytesRead);
		
		//Print the test results for the read
		if (timeOut == TIME_OUT)
			_ftprintf(testResults, _T("Read Timeout! Attempting %d byte read. \r\n Actually read %d Bytes \n"),k*64, dwBytesRead);
		else
			_ftprintf(testResults, _T("Read %d Bytes\n"),dwBytesRead);

		//Determine if there was any typeof failure, and if so
		//Call the flush buffer routine
		for (int x = 1; x < k*64; x++)
		{
			if(input[x] != output[x])
			{
				SI_FlushBuffers(hFile, TRUE, TRUE);
				x = (k*64) + 1;
			}
		}

		//Reset bytes written and byes read
		dwBytesWritten = 0;
		dwBytesRead = 0;

		//Perform a write file of k* 64 + 1
		SI_Write(hFile, &output, (k*64)+1, &dwBytesWritten);

		//Determine how many bytes were written and output the status
		if (dwBytesWritten ==0)
			_ftprintf(testResults,  _T("Write Failed %d Bytes\n"), (k*64)+1);
		else
			_ftprintf(testResults,  _T("Write Succeeded %d Bytes\n"), (k*64)+1);

		//Reset timeout and recieve queue bytes
		timeOut = 0;
		checkRXBytes = 0;

		//Keep checking the recieve queue until timeout occurs, or
		//the number of bytes just written is in the queue
		while ((checkRXBytes != dwBytesWritten)&& (timeOut!=TIME_OUT))
		{
			SI_CheckRXQueue(hFile, &checkRXBytes, &queueStatus);
			timeOut++;
		}

		//Perform the read on k * 64 + 1 chunk of data we just wrote
		SI_Read(hFile, &input, (k*64)+1, &dwBytesRead);
		
		if (timeOut == TIME_OUT)
			_ftprintf(testResults, _T("Read Timeout! Attempting %d byte read. \r\n Actually read %d Bytes \n"),(k*64)+1, dwBytesRead);
		else
			_ftprintf(testResults, _T("Read %d Bytes\n"),(k*64)+1);

		//Determine if there was any typeof failure, and if so
		//Call the flush buffer routine
		for (x = 1; x < (k*64) + 1; x++)
		{
			if(input[x] != output[x])
			{
				_ftprintf(testResults, _T("Verify Failure Input: %d Output: %d\n"),input[x], output[x]);
				SI_FlushBuffers(hFile, TRUE, TRUE);
				x = (k*64) + 1;
			}
		}

		//Reset bytes written and byes read
		dwBytesWritten = 0;
		dwBytesRead = 0;
	}

	return;
}

void TryKnownBaudRates(HANDLE cyHandle)
{
	SI_STATUS status = SI_SUCCESS;
	DWORD dwbaudrate = 0;

	//Loop through each of the 28 baud rates
	for (int i = 0; i <= 28; i++)
	{
		//Try setting the baud rate
		status = SI_SetBaudRate(cyHandle, BaudRates[i]);

		//Print the results of the baud rate setting
		if (status != SI_SUCCESS)
			_ftprintf(testResults, _T("Error setting baudrate %d\n"), BaudRates[i]);

		//Try getting the baud rate
		status = SI_GetBaudRate(cyHandle, (LPDWORD) &dwbaudrate);

		//Print the results of the baud rate get, and determine if it is right or not
		if (status != SI_SUCCESS)
			_ftprintf(testResults, _T("Error getting baudrate %d\n"), dwbaudrate);
		else
		{
			if (dwbaudrate == BaudRates[i])
				_ftprintf(testResults, _T("Success setting baudrate %d\n"), BaudRates[i]);
			else
				_ftprintf(testResults, _T("Error setting baudrate %d\n"), BaudRates[i]);
		}

	}

	//Set the baud rate to a standadrd 115200 baud rate
	status = SI_SetBaudRate(cyHandle, 115200);

	//Print the results of that set
	if (status != SI_SUCCESS)
		_ftprintf(testResults, _T("Error setting baudrate 115200\n"));

	return;
}

