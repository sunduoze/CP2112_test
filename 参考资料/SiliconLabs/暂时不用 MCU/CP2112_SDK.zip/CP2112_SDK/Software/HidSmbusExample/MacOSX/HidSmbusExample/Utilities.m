/////////////////////////////////////////////////////////////////////////////
// Utilities.m
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// Includes
/////////////////////////////////////////////////////////////////////////////

#include "Utilities.h"

/////////////////////////////////////////////////////////////////////////////
// Public Functions
/////////////////////////////////////////////////////////////////////////////

NSString* HidSmbus_DecodeErrorStatus(HID_SMBUS_STATUS status)
{
	NSString* str;

	switch (status)
	{
	case HID_SMBUS_SUCCESS:					str = @"HID_SMBUS_SUCCESS";					break;
	case HID_SMBUS_DEVICE_NOT_FOUND:		str = @"HID_SMBUS_DEVICE_NOT_FOUND";		break;
	case HID_SMBUS_INVALID_HANDLE:			str = @"HID_SMBUS_INVALID_HANDLE";			break;
	case HID_SMBUS_INVALID_DEVICE_OBJECT:	str = @"HID_SMBUS_INVALID_DEVICE_OBJECT";	break;
	case HID_SMBUS_INVALID_PARAMETER:		str = @"HID_SMBUS_INVALID_PARAMETER";		break;
	case HID_SMBUS_INVALID_REQUEST_LENGTH:	str = @"HID_SMBUS_INVALID_REQUEST_LENGTH";	break;
	case HID_SMBUS_READ_ERROR:				str = @"HID_SMBUS_READ_ERROR";				break;
	case HID_SMBUS_WRITE_ERROR:				str = @"HID_SMBUS_WRITE_ERROR";				break;
	case HID_SMBUS_READ_TIMED_OUT:			str = @"HID_SMBUS_READ_TIMED_OUT";			break;
	case HID_SMBUS_WRITE_TIMED_OUT:			str = @"HID_SMBUS_WRITE_TIMED_OUT";			break;
	case HID_SMBUS_DEVICE_IO_FAILED:		str = @"HID_SMBUS_DEVICE_IO_FAILED";		break;
	case HID_SMBUS_DEVICE_ACCESS_ERROR:		str = @"HID_SMBUS_DEVICE_ACCESS_ERROR";		break;
	case HID_SMBUS_DEVICE_NOT_SUPPORTED:	str = @"HID_SMBUS_DEVICE_NOT_SUPPORTED";	break;
	case HID_SMBUS_UNKNOWN_ERROR:			str = @"HID_SMBUS_UNKNOWN_ERROR";			break;
	default:								str = @"Unknown Status";
	}

	return str;
}

NSString* HidSmbus_DecodeTransferStatus(HID_SMBUS_S0 status0)
{
	NSString* str;

	switch (status0)
	{
	case HID_SMBUS_S0_IDLE:			str = @"Idle";				break;
	case HID_SMBUS_S0_BUSY:			str = @"Busy";				break;
	case HID_SMBUS_S0_COMPLETE:		str = @"Complete";			break;
	case HID_SMBUS_S0_ERROR:		str = @"Error";				break;
	default:						str = @"Unknown Status";	break;
	}

	return str;
}

NSString* HidSmbus_DecodeTransferStatuses(HID_SMBUS_S0 status0, HID_SMBUS_S1 status1)
{
	NSString* str;

	switch (status0)
	{
	case HID_SMBUS_S0_IDLE:			str = @"Idle";			break;
	case HID_SMBUS_S0_BUSY:			str = @"Busy - ";		break;
	case HID_SMBUS_S0_COMPLETE:		str = @"Complete";		break;
	case HID_SMBUS_S0_ERROR:		str = @"Error - ";		break;
	default:						str = @"Unknown Status";	break;
	}

	if (status0 == HID_SMBUS_S0_BUSY)
	{
		switch (status1)
		{
		case HID_SMBUS_S1_BUSY_ADDRESS_ACKED:	str = [str stringByAppendingString:@"Address Acked"];		break;
		case HID_SMBUS_S1_BUSY_ADDRESS_NACKED:	str = [str stringByAppendingString:@"Address Nacked"];		break;
		case HID_SMBUS_S1_BUSY_READING:			str = [str stringByAppendingString:@"Read in Progress"];	break;
		case HID_SMBUS_S1_BUSY_WRITING:			str = [str stringByAppendingString:@"Write in Progress"];	break;
		default:								str = [str stringByAppendingString:@"Unknown Status"];		break;
		}
	}
	else if (status0 == HID_SMBUS_S0_ERROR)
	{
		switch (status1)
		{
		case HID_SMBUS_S1_ERROR_TIMEOUT_NACK:			str = [str stringByAppendingString:@"Timeout (Address Nacked)"];	break;
		case HID_SMBUS_S1_ERROR_TIMEOUT_BUS_NOT_FREE:	str = [str stringByAppendingString:@"Timeout (Bus Not Free)"];		break;
		case HID_SMBUS_S1_ERROR_ARB_LOST:				str = [str stringByAppendingString:@"Arbitration Lost"];			break;
		case HID_SMBUS_S1_ERROR_READ_INCOMPLETE:		str = [str stringByAppendingString:@"Read Incomplete"];				break;
		case HID_SMBUS_S1_ERROR_WRITE_INCOMPLETE:		str = [str stringByAppendingString:@"Write Incomplete"];			break;
		case HID_SMBUS_S1_ERROR_SUCCESS_AFTER_RETRY:	str = [str stringByAppendingString:@"Success After Retries"];		break;
		default:										str = [str stringByAppendingString:@"Unknown Status"];				break;
		}
	}

	return str;
}
