var group___port_config_defs_struct_p_o_r_t___c_o_n_f_i_g =
[
    [ "EnhancedFxn", "group___port_config_defs.html#adfdcce53334ac060a451b97947b3670b", null ],
    [ "Mode", "group___port_config_defs.html#aef3d17d77a6f222faf1aca4b96bf0cc6", null ],
    [ "Reset_Latch", "group___port_config_defs.html#a8d269419b55dec2a03172f801507871e", null ],
    [ "Suspend_Latch", "group___port_config_defs.html#a4234638130fc845942c7852f1ec97977", null ]
];