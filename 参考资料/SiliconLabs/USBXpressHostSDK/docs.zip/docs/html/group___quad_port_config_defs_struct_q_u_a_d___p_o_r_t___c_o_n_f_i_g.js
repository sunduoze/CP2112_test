var group___quad_port_config_defs_struct_q_u_a_d___p_o_r_t___c_o_n_f_i_g =
[
    [ "EnhancedFxn_Device", "group___quad_port_config_defs.html#a08b8b62130cbcdefbaab76014b6c1fe6", null ],
    [ "EnhancedFxn_IFC0", "group___quad_port_config_defs.html#a9744a655ca638c480359bd2ef596bde9", null ],
    [ "EnhancedFxn_IFC1", "group___quad_port_config_defs.html#ab0dfae1ec36b439cb35e156f833fa8a5", null ],
    [ "EnhancedFxn_IFC2", "group___quad_port_config_defs.html#a625e5d4bd9b162948edfefb3ee14a9be", null ],
    [ "EnhancedFxn_IFC3", "group___quad_port_config_defs.html#ac897fbdd57675d7e9b1c5088894bfa3e", null ],
    [ "ExtClk0Freq", "group___quad_port_config_defs.html#a779f8c691ba332908d7f61c0b490c51b", null ],
    [ "ExtClk1Freq", "group___quad_port_config_defs.html#a4cd4fdef8e6be29eecc68e01701e696c", null ],
    [ "ExtClk2Freq", "group___quad_port_config_defs.html#ae07854caae8d63cb87ad1a00def1afbd", null ],
    [ "ExtClk3Freq", "group___quad_port_config_defs.html#a9ef8b1e429664a01dbca6f803c81dfc6", null ],
    [ "IPDelay_IFC0", "group___quad_port_config_defs.html#a296ad5c6b2ec9466e42ebfc936606255", null ],
    [ "IPDelay_IFC1", "group___quad_port_config_defs.html#afbebcb8190b6f2c3a74c9492e2aaab17", null ],
    [ "IPDelay_IFC2", "group___quad_port_config_defs.html#a0e747f12c1c02bb174f44c1dde312be8", null ],
    [ "IPDelay_IFC3", "group___quad_port_config_defs.html#a1ad11a118273ef318ff4ece72c18fa7f", null ],
    [ "Reset_Latch", "group___quad_port_config_defs.html#ad3f4a80128be9ef89c508dfed8047377", null ],
    [ "Suspend_Latch", "group___quad_port_config_defs.html#a0f2e42f1f22677246319e2f518f79b62", null ]
];