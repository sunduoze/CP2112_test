var group__slabiop_struct_s_i_l_a_b_s___i_o_p___a_n_a_l_o_g___p_i_n___v_a_l_u_e =
[
    [ "PinNumber", "group__slabiop.html#a85d291a207068202b154d965fe41b5d4", null ],
    [ "PinValue", "group__slabiop.html#a4b8c6c627b6fe5a10be1445581782112", null ],
    [ "TimeStamp", "group__slabiop.html#a379ccbec0a38dde8a28d28bae388447e", null ]
];