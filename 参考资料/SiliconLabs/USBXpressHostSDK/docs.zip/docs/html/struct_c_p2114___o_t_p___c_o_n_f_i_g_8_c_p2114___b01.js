var struct_c_p2114___o_t_p___c_o_n_f_i_g_8_c_p2114___b01 =
[
    [ "DacConfig", "struct_c_p2114___o_t_p___c_o_n_f_i_g_8_c_p2114___b01.html#ad8baf4c08370bf53a71ac5ecac5f56a8", null ],
    [ "RemConfig", "struct_c_p2114___o_t_p___c_o_n_f_i_g_8_c_p2114___b01.html#a5606a52d7b4f67c393dfa23d69ee683f", null ]
];