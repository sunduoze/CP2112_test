var annotated_dup =
[
    [ "_RAM_CONFIG_STRUCT", "struct___r_a_m___c_o_n_f_i_g___s_t_r_u_c_t.html", "struct___r_a_m___c_o_n_f_i_g___s_t_r_u_c_t" ],
    [ "CP2114_OTP_CONFIG.CP2114_B01", "struct_c_p2114___o_t_p___c_o_n_f_i_g_8_c_p2114___b01.html", "struct_c_p2114___o_t_p___c_o_n_f_i_g_8_c_p2114___b01" ],
    [ "CP2114_OTP_CONFIG.CP2114_B02", "struct_c_p2114___o_t_p___c_o_n_f_i_g_8_c_p2114___b02.html", "struct_c_p2114___o_t_p___c_o_n_f_i_g_8_c_p2114___b02" ],
    [ "PBAUD_CONFIG", "group___baud_rate_aliasing_defines.html#struct_b_a_u_d___c_o_n_f_i_g", "group___baud_rate_aliasing_defines_struct_b_a_u_d___c_o_n_f_i_g" ],
    [ "PCP2114_OTP_CONFIG", "union_c_p2114___o_t_p___c_o_n_f_i_g.html", "union_c_p2114___o_t_p___c_o_n_f_i_g" ],
    [ "PCP2114_OTP_CONFIG_GET", "struct_c_p2114___o_t_p___c_o_n_f_i_g___g_e_t.html", "struct_c_p2114___o_t_p___c_o_n_f_i_g___g_e_t" ],
    [ "PDUAL_PORT_CONFIG", "group___dual_port_config_defs.html#struct_d_u_a_l___p_o_r_t___c_o_n_f_i_g", "group___dual_port_config_defs_struct_d_u_a_l___p_o_r_t___c_o_n_f_i_g" ],
    [ "pFirmware_t", "group__manufacturing.html#structfirmware__t", "group__manufacturing_structfirmware__t" ],
    [ "PPORT_CONFIG", "group___port_config_defs.html#struct_p_o_r_t___c_o_n_f_i_g", "group___port_config_defs_struct_p_o_r_t___c_o_n_f_i_g" ],
    [ "PQUAD_PORT_CONFIG", "group___quad_port_config_defs.html#struct_q_u_a_d___p_o_r_t___c_o_n_f_i_g", "group___quad_port_config_defs_struct_q_u_a_d___p_o_r_t___c_o_n_f_i_g" ],
    [ "PQUAD_PORT_STATE", "group___quad_port_config_defs.html#struct_q_u_a_d___p_o_r_t___s_t_a_t_e", "group___quad_port_config_defs_struct_q_u_a_d___p_o_r_t___s_t_a_t_e" ],
    [ "SILABS_IOP_ACCESSORY_INFO", "group__slabiop.html#struct_s_i_l_a_b_s___i_o_p___a_c_c_e_s_s_o_r_y___i_n_f_o", "group__slabiop_struct_s_i_l_a_b_s___i_o_p___a_c_c_e_s_s_o_r_y___i_n_f_o" ],
    [ "SILABS_IOP_ANALOG_PIN_VALUE", "group__slabiop.html#struct_s_i_l_a_b_s___i_o_p___a_n_a_l_o_g___p_i_n___v_a_l_u_e", "group__slabiop_struct_s_i_l_a_b_s___i_o_p___a_n_a_l_o_g___p_i_n___v_a_l_u_e" ],
    [ "SILABS_IOP_DIGITAL_PORT_VALUE", "group__slabiop.html#struct_s_i_l_a_b_s___i_o_p___d_i_g_i_t_a_l___p_o_r_t___v_a_l_u_e", "group__slabiop_struct_s_i_l_a_b_s___i_o_p___d_i_g_i_t_a_l___p_o_r_t___v_a_l_u_e" ],
    [ "SILABS_IOP_PORT_CONFIGURATION", "group__slabiop.html#struct_s_i_l_a_b_s___i_o_p___p_o_r_t___c_o_n_f_i_g_u_r_a_t_i_o_n", "group__slabiop_struct_s_i_l_a_b_s___i_o_p___p_o_r_t___c_o_n_f_i_g_u_r_a_t_i_o_n" ],
    [ "SILABS_IOP_SERIAL_STATE", "group__slabiop.html#struct_s_i_l_a_b_s___i_o_p___s_e_r_i_a_l___s_t_a_t_e", "group__slabiop_struct_s_i_l_a_b_s___i_o_p___s_e_r_i_a_l___s_t_a_t_e" ],
    [ "tDeviceCaps", "structt_device_caps.html", "structt_device_caps" ]
];