var group___r_t_c_p210x___s_t_a_t_u_s =
[
    [ "CP210x_COMMAND_FAILED", "group___r_t_c_p210x___s_t_a_t_u_s.html#gab3f271e4ccc3610cf1e2f28d8fbb3b62", null ],
    [ "CP210x_DEVICE_IO_FAILED", "group___r_t_c_p210x___s_t_a_t_u_s.html#gae25cc1d6532cc93cb7f4c301573f7358", null ],
    [ "CP210x_DEVICE_NOT_FOUND", "group___r_t_c_p210x___s_t_a_t_u_s.html#gacc9ced90cbc9a32eeaf71087b6cd6e0c", null ],
    [ "CP210x_FILE_ERROR", "group___r_t_c_p210x___s_t_a_t_u_s.html#ga0080c3c937841d59b92964e8517f7303", null ],
    [ "CP210x_FUNCTION_NOT_SUPPORTED", "group___r_t_c_p210x___s_t_a_t_u_s.html#ga3f3fc94c588ab36ad0f535d98e962158", null ],
    [ "CP210x_GLOBAL_DATA_ERROR", "group___r_t_c_p210x___s_t_a_t_u_s.html#ga683a3cb6a2f891473c355a1ba93d2cda", null ],
    [ "CP210x_INVALID_ACCESS_TYPE", "group___r_t_c_p210x___s_t_a_t_u_s.html#gac5f1f66ed8c9d57b7140f5857cd588d2", null ],
    [ "CP210x_INVALID_HANDLE", "group___r_t_c_p210x___s_t_a_t_u_s.html#ga91fb08ab03a9b63c0444c6b66d0a6410", null ],
    [ "CP210x_INVALID_PARAMETER", "group___r_t_c_p210x___s_t_a_t_u_s.html#ga8bba39cff0c173c370e12bbe15b1eaf0", null ],
    [ "CP210x_SUCCESS", "group___r_t_c_p210x___s_t_a_t_u_s.html#ga5ff8a3c20e3eb044846982aa2d960131", null ]
];