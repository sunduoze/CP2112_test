var group__slabiop_struct_s_i_l_a_b_s___i_o_p___d_i_g_i_t_a_l___p_o_r_t___v_a_l_u_e =
[
    [ "PinMask", "group__slabiop.html#aa4954563b3c081c65daf610ef5408bf2", null ],
    [ "PortNumber", "group__slabiop.html#a707677ae3c782a11cb0520cb72e196ed", null ],
    [ "PortValue", "group__slabiop.html#a2d45ccd744a34ecdbba898815a7b0239", null ]
];