var group__slabiop_struct_s_i_l_a_b_s___i_o_p___p_o_r_t___c_o_n_f_i_g_u_r_a_t_i_o_n =
[
    [ "PinDirection", "group__slabiop.html#abf27a87f55bc24a1685255d0ab728378", null ],
    [ "PinFunction", "group__slabiop.html#acd477c4abcd9645c886c28c7fa1df8e5", null ],
    [ "PinOutMode", "group__slabiop.html#a0f772e92610c54fe0b76043264234f90", null ],
    [ "PortNumber", "group__slabiop.html#a8e19679de8f79532a023d58b3efa43bb", null ]
];