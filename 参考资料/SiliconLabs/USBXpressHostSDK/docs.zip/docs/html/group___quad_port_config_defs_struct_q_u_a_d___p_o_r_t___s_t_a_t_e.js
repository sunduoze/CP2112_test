var group___quad_port_config_defs_struct_q_u_a_d___p_o_r_t___s_t_a_t_e =
[
    [ "Latch_PB0", "group___quad_port_config_defs.html#aadab733d5a98ab07d391b512c47daf61", null ],
    [ "Latch_PB1", "group___quad_port_config_defs.html#aa3a37ddef012f4cbd6a013b61a8b8434", null ],
    [ "Latch_PB2", "group___quad_port_config_defs.html#ac218c050323694d1e91cf903f1b5ba71", null ],
    [ "Latch_PB3", "group___quad_port_config_defs.html#a9296baee19ccefa3566e6b6895c8085c", null ],
    [ "Latch_PB4", "group___quad_port_config_defs.html#a8f6ac986db74595d93809db401b7d5c5", null ],
    [ "LowPower_PB0", "group___quad_port_config_defs.html#a5664f3344b7d15e125f90ed55c8997a1", null ],
    [ "LowPower_PB1", "group___quad_port_config_defs.html#ac227aaa63181156d7b494a2572f509a3", null ],
    [ "LowPower_PB2", "group___quad_port_config_defs.html#a28dfded99cc9ac5fa7cdfa16d1092d53", null ],
    [ "LowPower_PB3", "group___quad_port_config_defs.html#a716f694d0189d1577cc6dddf16e19bc7", null ],
    [ "LowPower_PB4", "group___quad_port_config_defs.html#add13a817442ec00576b384920386f2de", null ],
    [ "Mode_PB0", "group___quad_port_config_defs.html#ac1a87573d27fa9b3841a4c50edb8cd1a", null ],
    [ "Mode_PB1", "group___quad_port_config_defs.html#a7c2060ddf3adc68c9703930d2a6f9a4a", null ],
    [ "Mode_PB2", "group___quad_port_config_defs.html#ac52cdc5990a58bec598ed1023cd3b0a5", null ],
    [ "Mode_PB3", "group___quad_port_config_defs.html#ad04596f0ffd0c2b04088d3a67f1ca758", null ],
    [ "Mode_PB4", "group___quad_port_config_defs.html#a0893b910c522031b85193706e33878cb", null ]
];