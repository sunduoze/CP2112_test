var group___baud_rate_aliasing_defines_struct_b_a_u_d___c_o_n_f_i_g =
[
    [ "BaudGen", "group___baud_rate_aliasing_defines.html#a60f250462e890311054a88c8a080f658", null ],
    [ "BaudRate", "group___baud_rate_aliasing_defines.html#a054bc697257711af8d0434638e1c4f61", null ],
    [ "Prescaler", "group___baud_rate_aliasing_defines.html#a88fe8201ae4699758b58152197b0b219", null ],
    [ "Timer0Reload", "group___baud_rate_aliasing_defines.html#aee1df7203bd683950c23f8aa29a5b21b", null ]
];