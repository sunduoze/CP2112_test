var modules =
[
    [ "Silabs_defs", "group__silabs__defs.html", "group__silabs__defs" ],
    [ "CP201x Manufacturing Library", "group__manufacturing.html", "group__manufacturing" ],
    [ "CP201x Runtime Library", "group__runtime.html", "group__runtime" ],
    [ "CP201x DirectAccess (nee USBXpress) Library", "group___direct_access.html", "group___direct_access" ],
    [ "CP211x HID-based interface Library", "group__slabhiddevice.html", "group__slabhiddevice" ],
    [ "CP2112 SMBus over HID interface Library", "group__slabhidsmbus.html", "group__slabhidsmbus" ],
    [ "CP211X Serial over HID Library", "group__slabhiduart.html", "group__slabhiduart" ],
    [ "IOP Library", "group__slabiop.html", "group__slabiop" ]
];