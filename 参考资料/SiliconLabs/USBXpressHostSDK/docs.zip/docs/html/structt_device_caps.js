var structt_device_caps =
[
    [ "availableBootIndices", "structt_device_caps.html#a38a8f1f74e620c1cf6eb606d7c951083", null ],
    [ "availableOtpConfigs", "structt_device_caps.html#a10371838bd2b269748d3f0c1a1499aab", null ],
    [ "availableOtpConfigSpace_LSB", "structt_device_caps.html#a88acf7b171ccf0e82fa5f4ce53804b26", null ],
    [ "availableOtpConfigSpace_MSB", "structt_device_caps.html#a71b7c67520982fa41ffd2a3465376096", null ],
    [ "currentBootConfig", "structt_device_caps.html#aaad997b4a8cf0ec907b3745ecaa4587f", null ]
];