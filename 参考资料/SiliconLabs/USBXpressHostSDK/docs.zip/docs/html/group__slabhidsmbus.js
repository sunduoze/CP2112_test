var group__slabhidsmbus =
[
    [ "HID_SMBUS_DEVICE_ALREADY_OPENED", "group__slabhidsmbus.html#gaa340cceec7c31d65f87137ed663c2165", null ],
    [ "HID_SMBUS_LOCK_LOCKED", "group__slabhidsmbus.html#gafcb11d886cfd9f4938b907aaebd181c8", null ],
    [ "HID_SMBUS_LOCK_UNLOCKED", "group__slabhidsmbus.html#gab30079335c024cdc5081b4eeb1ef0131", null ],
    [ "HID_SMBUS_GETSTRING", "group__slabhidsmbus.html#ga570b1173982a41ada12cdd1239298b07", [
      [ "HID_SMBUS_GET_VID_STR", "group__slabhidsmbus.html#gga570b1173982a41ada12cdd1239298b07abd88956845acf4acddcc13345cc0165a", null ],
      [ "HID_SMBUS_GET_PID_STR", "group__slabhidsmbus.html#gga570b1173982a41ada12cdd1239298b07aa0b71dc85a9017938fec723b579bef50", null ],
      [ "HID_SMBUS_GET_PATH_STR", "group__slabhidsmbus.html#gga570b1173982a41ada12cdd1239298b07a23c566f7d2896ea008ae4d6df2d7b750", null ],
      [ "HID_SMBUS_GET_SERIAL_STR", "group__slabhidsmbus.html#gga570b1173982a41ada12cdd1239298b07ab9e270d8c40c8fbbb2d4e242d63de361", null ],
      [ "HID_SMBUS_GET_MANUFACTURER_STR", "group__slabhidsmbus.html#gga570b1173982a41ada12cdd1239298b07aae9f72f3288fd6ff3b4142e0faad60ee", null ],
      [ "HID_SMBUS_GET_PRODUCT_STR", "group__slabhidsmbus.html#gga570b1173982a41ada12cdd1239298b07aaaf560ff23408a19140b9a886dacbf1e", null ]
    ] ],
    [ "HID_SMBUS_LOCKBITS", "group__slabhidsmbus.html#ga3c6cb7537ed5dccb42935d9a691ab14a", [
      [ "HID_SMBUS_LOCK_VID", "group__slabhidsmbus.html#gga3c6cb7537ed5dccb42935d9a691ab14aa81314dfcd99e67ccc5692f988aa48ce4", null ],
      [ "HID_SMBUS_LOCK_PID", "group__slabhidsmbus.html#gga3c6cb7537ed5dccb42935d9a691ab14aa61962110067e0ec63a4bb13b1503b729", null ],
      [ "HID_SMBUS_LOCK_POWER", "group__slabhidsmbus.html#gga3c6cb7537ed5dccb42935d9a691ab14aa784ae75a4a8c10ef360a44b59b1cd7cf", null ],
      [ "HID_SMBUS_LOCK_POWER_MODE", "group__slabhidsmbus.html#gga3c6cb7537ed5dccb42935d9a691ab14aa97c35f1ec132d0204eb4a225a1da2106", null ],
      [ "HID_SMBUS_LOCK_RELEASE_VERSION", "group__slabhidsmbus.html#gga3c6cb7537ed5dccb42935d9a691ab14aae3ff27486e41faa71d9367974c5b5636", null ],
      [ "HID_SMBUS_LOCK_MFG_STR", "group__slabhidsmbus.html#gga3c6cb7537ed5dccb42935d9a691ab14aad27b630d65fb52ba301b7101dbb1a5a9", null ],
      [ "HID_SMBUS_LOCK_PRODUCT_STR", "group__slabhidsmbus.html#gga3c6cb7537ed5dccb42935d9a691ab14aa7a5cc0e2e2fc132943106029e4d9966f", null ],
      [ "HID_SMBUS_LOCK_SERIAL_STR", "group__slabhidsmbus.html#gga3c6cb7537ed5dccb42935d9a691ab14aa5863b87732d19489338fccf2513d6849", null ]
    ] ],
    [ "HidSmbus_Close", "group__slabhidsmbus.html#ga3bd2d986999d4064ea24eeeda9b89f90", null ],
    [ "HidSmbus_GetHidLibraryVersion", "group__slabhidsmbus.html#ga8649a7fd01aaad08042b77942e17742b", null ],
    [ "HidSmbus_GetLibraryVersion", "group__slabhidsmbus.html#ga68f121510bfcfcadaf975f2b974b1bea", null ],
    [ "HidSmbus_GetLock", "group__slabhidsmbus.html#ga83dd963498ba57ff4ea8a1065b1c02db", null ],
    [ "HidSmbus_GetNumDevices", "group__slabhidsmbus.html#gafa8df790a7486dceb8799ada0a2c7954", null ],
    [ "HidSmbus_GetOpenedString", "group__slabhidsmbus.html#ga0d746638a43a003850311da1a6b0cfe5", null ],
    [ "HidSmbus_GetPartNumber", "group__slabhidsmbus.html#ga970ce6522eecfbcd9c6b2137353c413a", null ],
    [ "HidSmbus_GetString", "group__slabhidsmbus.html#gace83aeb93ff85fec64e32599af76b2b7", null ],
    [ "HidSmbus_IsOpened", "group__slabhidsmbus.html#gabf845c9e0b7dab8b25a9c9f3e6e5f30a", null ],
    [ "HidSmbus_ReadLatch", "group__slabhidsmbus.html#gaca974c285f0aa158b03f93e2cdde8385", null ],
    [ "HidSmbus_WriteLatch", "group__slabhidsmbus.html#ga4166e48f4fe980917469197462fc43e4", null ]
];