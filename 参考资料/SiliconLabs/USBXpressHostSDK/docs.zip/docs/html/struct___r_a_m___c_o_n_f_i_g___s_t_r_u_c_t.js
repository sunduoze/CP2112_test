var struct___r_a_m___c_o_n_f_i_g___s_t_r_u_c_t =
[
    [ "configData", "struct___r_a_m___c_o_n_f_i_g___s_t_r_u_c_t.html#a1500d97c54c661293bc1d3773d22a3c8", null ],
    [ "Length", "struct___r_a_m___c_o_n_f_i_g___s_t_r_u_c_t.html#ab02e81d4019cd9849975e175907ca343", null ]
];