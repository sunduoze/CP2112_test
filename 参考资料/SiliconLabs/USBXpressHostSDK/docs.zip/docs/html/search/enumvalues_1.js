var searchData=
[
  ['device_5fi2c_5fstatus_5fbus_5fbusy',['DEVICE_I2C_STATUS_BUS_BUSY',['../group__slabiop.html#ggae16a96166298bf0653fa9e23f7faf0fea06c3efab8af6c1ba59484503b667de63',1,'slabiop.h']]],
  ['device_5fi2c_5fstatus_5fbus_5ferror',['DEVICE_I2C_STATUS_BUS_ERROR',['../group__slabiop.html#ggae16a96166298bf0653fa9e23f7faf0fea088c9e46fadbc904ff9e062a7ef44787',1,'slabiop.h']]],
  ['device_5fi2c_5fstatus_5fcfg_5flocked',['DEVICE_I2C_STATUS_CFG_LOCKED',['../group__slabiop.html#ggae16a96166298bf0653fa9e23f7faf0fea974b40e5fc7f6c9a6fe6e2566f172cd0',1,'slabiop.h']]],
  ['device_5fi2c_5fstatus_5finvalid_5fparameter',['DEVICE_I2C_STATUS_INVALID_PARAMETER',['../group__slabiop.html#ggae16a96166298bf0653fa9e23f7faf0feaad909b469c61815d42c3ec62f86676fb',1,'slabiop.h']]],
  ['device_5fi2c_5fstatus_5fsuccess',['DEVICE_I2C_STATUS_SUCCESS',['../group__slabiop.html#ggae16a96166298bf0653fa9e23f7faf0feabd0606e81cd920dc1dee8ee7b9e8c029',1,'slabiop.h']]],
  ['device_5fi2c_5fstatus_5ftimeout',['DEVICE_I2C_STATUS_TIMEOUT',['../group__slabiop.html#ggae16a96166298bf0653fa9e23f7faf0fea510661c2aa8ee4d21744ec7403b9f424',1,'slabiop.h']]]
];
