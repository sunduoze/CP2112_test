var searchData=
[
  ['si_5fstatus',['SI_STATUS',['../group___direct_access.html#gae1ffce36e138e9742b347f28941a80ce',1,'SiUSBXp.h']]],
  ['silabs_5fiop_5finterface_5falternate_5fsettings',['SILABS_IOP_INTERFACE_ALTERNATE_SETTINGS',['../group__slabiop.html#gac85d1dc4c47a3f0d02de499619e04b43',1,'slabiop.h']]],
  ['silabs_5fpartnum_5fcpxxxx',['SILABS_PARTNUM_CPXXXX',['../group__silabs__defs.html#ga8bc33a7f1ed65a87143973da242dd04d',1,'silabs_defs.h']]],
  ['silabs_5fpid',['SILABS_PID',['../group__silabs__defs.html#ga5b01e7352eca134cc586d24b21e598dd',1,'silabs_defs.h']]],
  ['silabs_5fstatus',['SILABS_STATUS',['../group__silabs__defs.html#ga704db2068fdbb3ab2d7f584b070770ce',1,'silabs_defs.h']]],
  ['silabs_5fvid',['SILABS_VID',['../group__silabs__defs.html#ga9e60b1563a79d4d41440882de2283f03',1,'silabs_defs.h']]]
];
