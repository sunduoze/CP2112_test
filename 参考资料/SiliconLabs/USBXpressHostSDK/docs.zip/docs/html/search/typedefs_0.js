var searchData=
[
  ['baud_5fconfig_5fdata',['BAUD_CONFIG_DATA',['../group___baud_rate_aliasing_defines.html#gac192058465d80b07c925bf4d6e60f8c9',1,'CP210xManufacturingDLL.h']]]
];
