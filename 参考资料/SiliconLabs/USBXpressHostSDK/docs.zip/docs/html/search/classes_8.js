var searchData=
[
  ['tdevicecaps',['tDeviceCaps',['../structt_device_caps.html',1,'']]]
];
