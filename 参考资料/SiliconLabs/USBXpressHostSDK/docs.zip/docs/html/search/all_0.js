var searchData=
[
  ['_5fram_5fconfig_5fstruct',['_RAM_CONFIG_STRUCT',['../struct___r_a_m___c_o_n_f_i_g___s_t_r_u_c_t.html',1,'']]]
];
