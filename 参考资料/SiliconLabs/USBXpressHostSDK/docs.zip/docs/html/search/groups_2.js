var searchData=
[
  ['dualportconfigdefs',['DualPortConfigDefs',['../group___dual_port_config_defs.html',1,'']]]
];
