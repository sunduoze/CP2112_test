var searchData=
[
  ['dual_5fport_5fconfig',['DUAL_PORT_CONFIG',['../group___dual_port_config_defs.html#struct_d_u_a_l___p_o_r_t___c_o_n_f_i_g',1,'']]]
];
