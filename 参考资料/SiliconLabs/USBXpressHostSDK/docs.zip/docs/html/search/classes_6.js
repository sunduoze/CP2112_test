var searchData=
[
  ['quad_5fport_5fconfig',['QUAD_PORT_CONFIG',['../group___quad_port_config_defs.html#struct_q_u_a_d___p_o_r_t___c_o_n_f_i_g',1,'']]],
  ['quad_5fport_5fstate',['QUAD_PORT_STATE',['../group___quad_port_config_defs.html#struct_q_u_a_d___p_o_r_t___s_t_a_t_e',1,'']]]
];
