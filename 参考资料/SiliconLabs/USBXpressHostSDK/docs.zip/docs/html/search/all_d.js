var searchData=
[
  ['receiveerror',['ReceiveError',['../group__slabiop.html#a8d250f8cc8b69dc1a46b5dff29ede585',1,'SILABS_IOP_SERIAL_STATE']]],
  ['rtcp210x_5fstatus',['RTCP210x_STATUS',['../group___r_t_c_p210x___s_t_a_t_u_s.html',1,'']]]
];
