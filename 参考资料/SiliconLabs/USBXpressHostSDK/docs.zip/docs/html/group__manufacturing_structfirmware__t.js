var group__manufacturing_structfirmware__t =
[
    [ "build", "group__manufacturing.html#a0da9288cdd8656b7a23de95bcf30a551", null ],
    [ "major", "group__manufacturing.html#a1f273c41a36224a7fe1d1f0774e9a05c", null ],
    [ "minor", "group__manufacturing.html#a6cbfa9de10dea27491754663e903a8b5", null ]
];