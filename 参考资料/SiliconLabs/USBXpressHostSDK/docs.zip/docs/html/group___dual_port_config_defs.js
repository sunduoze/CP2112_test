var group___dual_port_config_defs =
[
    [ "PDUAL_PORT_CONFIG", "group___dual_port_config_defs.html#struct_d_u_a_l___p_o_r_t___c_o_n_f_i_g", [
      [ "EnhancedFxn_Device", "group___dual_port_config_defs.html#a202151fc14937523e5e3412593bf8dec", null ],
      [ "EnhancedFxn_ECI", "group___dual_port_config_defs.html#ac75a7df9da593af34f36ab756a18ae46", null ],
      [ "EnhancedFxn_SCI", "group___dual_port_config_defs.html#a45566bc4279eae823e2eb406a1abc218", null ],
      [ "Mode", "group___dual_port_config_defs.html#a3c2544af1ed1c336186715406216e5e0", null ],
      [ "Reset_Latch", "group___dual_port_config_defs.html#ad0bcb951269fec1b7dcfff1edf71c16d", null ],
      [ "Suspend_Latch", "group___dual_port_config_defs.html#af0be856aa9fb10312999a9314882c2cc", null ]
    ] ]
];