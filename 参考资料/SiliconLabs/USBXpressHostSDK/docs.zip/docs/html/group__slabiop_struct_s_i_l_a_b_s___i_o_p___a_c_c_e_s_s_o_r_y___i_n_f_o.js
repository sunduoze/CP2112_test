var group__slabiop_struct_s_i_l_a_b_s___i_o_p___a_c_c_e_s_s_o_r_y___i_n_f_o =
[
    [ "OptionID", "group__slabiop.html#ab2f773aba05c472671fa71b880719a59", null ],
    [ "PartID", "group__slabiop.html#a63ee51d908a4a015f222a06909f86506", null ],
    [ "ProtocolVersion", "group__slabiop.html#a3a1fa44f96e146d52b97af15c59ff3fd", null ]
];