var NAVTREE =
[
  [ "Silicon Labs Host Libraries", "index.html", [
    [ "USB Bridge Host Libraries", "index.html", null ],
    [ "END-USER LICENSE AGREEMENT", "license.html", null ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"group__silabs__defs.html#gga5b01e7352eca134cc586d24b21e598dda6b85c8e1bfd4bcba4ab64dc078de03ce"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';